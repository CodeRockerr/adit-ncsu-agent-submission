"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.
"""

from __future__ import annotations

import re

from base_strategy import BaseStrategy, ChallengeContext


# Measured 2026-10-26. tests/logic_bench.py (generated ordering puzzles, 36 per
# model): gemini-3.8-flash 36/36 at ~6.5s, gpt-5.6-terra 31/36 at ~5s.
# tests/model_screen.py (30 tasks: logic, arithmetic, lookup, strict format,
# tools; each model alone through the full solver): gpt-5.6-terra 30/30 and
# gemini-3.6-flash 30/30 (median 3.1s / 3.8s); gemini-3.8-flash 26/30 (tools
# 2/6 alone); qwen3.7-max 23/30; gpt-5.4 20/30 (logic 0/6); the other qwens
# 15-21/30 and the nemotrons 7-10/30, with frequent timeouts. The order below
# is the direct-solving primary, then backups by screen score; aliases absent
# from the live roster are skipped.
# 2026-10-27 on Practice's own three logic puzzles (3 runs each, full solver):
# gpt-5.6-terra 9/9 at 3.2s mean (3.9s max); gemini-3.6-flash 7/9 at 11.8s
# (30.5s max); gemini-3.8-flash 9/9 at 14.5s (42.3s max). On harder generated
# puzzles gemini is more accurate alone (3.6: 54/54) but gpt with the clue
# checker reaches 77/78, so gpt leads for speed and gemini-3.6 (another
# provider) takes over only when the checker still finds a broken clue.
MEASURED_TEXT_PREFERENCE = (
    "gpt-5.6-terra",
    "gemini-3.6-flash",
    "gemini-3.8-flash",
    "qwen3.7-max",
    "qwen3.6-35b",
    "qwen3.7-flash",
    "qwen3.7-plus",
    "gpt-5.4",
    "nemotron-3-ultra",
    "nemotron-3.5-lightning",
    "nemotron-3-super",
)
# Tool exploration (13 mock scenarios + 6 in the screen): gpt-5.6-terra 6/6 at
# 5.3s; gemini-3.6-flash 6/6 at 7.2s; gpt-5.4 6/6 at 5.3s; qwen3.7-max 4/6.
MEASURED_EXPLORE_PREFERENCE = ("gpt-5.6-terra", "gemini-3.6-flash", "gpt-5.4", "qwen3.7-max", "gemini-3.8-flash")
# Image review: gpt-5.4 is the model Practice's image judge used, and the
# fastest at comparing two images (4.6s vs 5.1s gpt-5.6-terra, 7.0s gemini).
MEASURED_REVIEW_PREFERENCE = ("gpt-5.4", "gpt-5.6-terra", "gemini-3.8-flash")

# Seconds per successful direct call (median, p90), from saved logic_bench and
# model_screen runs on the Practice proxy, 2026-10-26/27. gpt-5.6-terra: n=125,
# max 10.8s; gemini-3.8-flash peaked at 53s and gemini-3.6-flash at 32s.
MEASURED_LATENCY_S = {
    "gpt-5.6-terra": (3.6, 6.2),
    "gpt-5.4": (1.3, 1.4),
    "gemini-3.6-flash": (6.2, 12.5),
    "gemini-3.8-flash": (6.1, 10.1),
    "qwen3.7-max": (11.3, 15.9),
    "qwen3.6-35b": (7.3, 25.1),
    "qwen3.7-flash": (8.3, 20.7),
    "qwen3.7-plus": (13.5, 21.8),
    "nemotron-3-super": (18.8, 25.9),
    "nemotron-3-ultra": (19.0, 29.5),
    "nemotron-3.5-lightning": (12.1, 40.9),
}

# Generation (tests/image_model_eval.py, 2026-10-26): flash-lite obeyed "no
# text" best (constraints 80 vs 56) at ~6s; Practice finals 91-96.
# Edits: our own gpt-5.4 judge preferred pro's preservation, but the official
# Practice judge did not. Across both teammates' runs (2026-10-26/27), final
# scores were flash-lite 88.3 (n=2, 8-15s), pro 86.6 (n=7, 22-26s) and flash
# 84.5 (n=3): official preservation was about 70-74 for all three, so the
# faster model wins on speed, at a third to a half of pro's cost.
MEASURED_EDIT_PREFERENCE = ("gemini-3.1-flash-lite-image", "gemini-3-pro-image", "gemini-3.1-flash-image")
MEASURED_GENERATE_PREFERENCE = ("gemini-3.1-flash-lite-image", "gemini-3.1-flash-image", "gemini-3-pro-image")

# Roster-agnostic fallback for aliases we have not measured: size/tier words
# in the alias are the only capability signal /models gives us.
_STRONG_ALIAS_WORDS = ("ultra", "max", "pro", "opus", "large", "super", "plus")
_WEAK_ALIAS_WORDS = ("lightning", "lite", "nano", "mini", "tiny", "small", "haiku")
_VERSION_RE = re.compile(r"(\d+(?:\.\d+)?)")

# Negations image models tend to ignore, restated as what to draw instead.
# The gap after the negation stops at punctuation so "without borders, featuring
# the words ..." is not read as "no text".
_NEGATION = r"(?:no|without|avoid|zero|free of|do not (?:add|include|show|render|use)|don't (?:add|include|show|render|use))"
_NO_TEXT_RE = re.compile(
    rf"\b{_NEGATION}\b[^.,;:\n]{{0,25}}?"
    r"\b(?:text|words?|letters?|lettering|typography|captions?|writing|characters|signage)\b"
    r"|\btext[- ]free\b",
    re.IGNORECASE,
)
_NO_LOGO_RE = re.compile(
    rf"\b{_NEGATION}\b[^.,;:\n]{{0,25}}?\b(?:logos?|watermarks?|brand(?:ing|s)?|trademarks?)\b",
    re.IGNORECASE,
)
# Instructions that ask for specific wording, e.g. a title in quotes.
_TEXT_REQUESTED_RE = re.compile(
    r"\b(?:that (?:says|reads)|reading|saying|with the (?:words?|text|title|caption)|titled|"
    r"caption(?:ed)? (?:with|reading)|labell?ed)\b|[\"“][^\"”]{1,40}[\"”]",
    re.IGNORECASE,
)
_NEGATED_PHRASE_RE = re.compile(
    rf"\b(?:{_NEGATION}|must not (?:contain|include|show))\s+"
    r"([a-z][a-z0-9 /'\-]{1,50}?)(?=[,.;:\n]|$)",
    re.IGNORECASE,
)


_COMMA_LIST_RE = re.compile(r"\bcomma[- ]?separated\b", re.IGNORECASE)
_NO_SPACES_RE = re.compile(r"\bno spaces?\b|\bwithout spaces?\b", re.IGNORECASE)
# Rules that want names kept whole: never shorten under these.
_KEEP_NAMES_RE = re.compile(
    r"\b(?:full|complete|exact(?:ly)?|verbatim|as (?:written|given|shown|listed)|including)\b", re.IGNORECASE
)


def normalize_list_answer(answer: str, rules: str) -> str:
    """Canonical form for a comma-separated list answer.

    The text judge is inconsistent about cosmetic differences: the same
    "Team Alpha,Team Bravo,..." answer was accepted once and rejected once
    for rules asking for "team names". So when every item starts with the
    category word the rules name ("team names" -> "Team"), drop it, and
    separate items with ", " unless the rules forbid spaces.
    """
    text = str(answer or "").strip()
    if not text or not _COMMA_LIST_RE.search(rules or ""):
        return text
    items = [item.strip() for item in text.split(",")]
    if len(items) < 2 or any(not item for item in items):
        return text
    first_words = {item.split()[0].casefold() for item in items}
    keep_names = bool(_KEEP_NAMES_RE.search(rules))
    if not keep_names and len(first_words) == 1 and all(len(item.split()) >= 2 for item in items):
        category = first_words.pop()
        if re.search(rf"\b{re.escape(category)}s? names?\b", rules, re.IGNORECASE):
            items = [item.split(None, 1)[1].strip() for item in items]
    separator = "," if _NO_SPACES_RE.search(rules) else ", "
    return separator.join(items)


def _alias_version(alias: str) -> float:
    match = _VERSION_RE.search(alias)
    try:
        return float(match.group(1)) if match else 0.0
    except ValueError:
        return 0.0


def _alias_tier(alias: str) -> int:
    lowered = alias.casefold()
    if any(word in lowered for word in _WEAK_ALIAS_WORDS):
        return 2
    if any(word in lowered for word in _STRONG_ALIAS_WORDS):
        return 0
    return 1


def image_constraint_lines(ctx: ChallengeContext) -> list[str]:
    """Hard constraints from the image instruction, phrased as what to draw."""
    source = "\n".join(part for part in (ctx.rules, ctx.challenge_text) if part)
    lines: list[str] = []
    if _NO_TEXT_RE.search(source):
        if _TEXT_REQUESTED_RE.search(source):
            lines.append(
                "No text other than the exact wording the instruction asks for; every "
                "other sign, screen, label and surface is blank or abstract."
            )
        else:
            lines.append(
                "The image contains zero readable characters. Every sign, screen, billboard, "
                "label, poster and surface is blank or shows only abstract shapes, glowing "
                "lines and light patterns. Neon lights are plain tubes and light streaks, "
                "not lettering."
            )
    if _NO_LOGO_RE.search(source):
        lines.append(
            "No logos, brand marks, emblems or watermarks anywhere (vehicles, products, "
            "clothing, frame corners), other than any the instruction explicitly asks for."
        )
    seen = {line.casefold() for line in lines}
    for match in _NEGATED_PHRASE_RE.finditer(source):
        phrase = match.group(1).strip()
        if _NO_TEXT_RE.search(f"no {phrase}") or _NO_LOGO_RE.search(f"no {phrase}"):
            continue
        line = f"Must not contain: {phrase}."
        if line.casefold() not in seen:
            seen.add(line.casefold())
            lines.append(line)
        if len(lines) >= 6:
            break
    return lines


class MyStrategy(BaseStrategy):
    """Default competitor strategy template."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "my-agent"
    agent_name = "Infinity Protocol"

    # Text challenge strategy
    text_system_prompt = (
        "You are a text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Return nothing except the required ANSWER line and optional brief reasoning lines after it. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'."
    )
    text_strategy_notes = "Keep reasoning concise and always include an ANSWER line."
    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192

    # Image challenge strategy
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Measured models first, then a fallback that fits the task.

        Image edits favor the strongest image model (it preserves the scene);
        image generation favors the measured "no text" winner, then roster
        order. For text, image-only aliases go last so a reasoning model leads.
        """
        if self.is_image_challenge(ctx):
            image_models = super().rank_models(ctx, available_models)
            editing = bool(ctx.image_url)
            preference = MEASURED_EDIT_PREFERENCE if editing else MEASURED_GENERATE_PREFERENCE
            ranks = {alias: index for index, alias in enumerate(preference)}

            def image_key(item: tuple[int, str]) -> tuple:
                roster_index, alias = item
                if alias in ranks:
                    return (0, ranks[alias], roster_index)
                return (1, _alias_tier(alias) if editing else 0, roster_index)

            return [alias for _, alias in sorted(enumerate(image_models), key=image_key)]

        image_only = set(self.prefer_image_models(available_models))
        measured = {alias: index for index, alias in enumerate(MEASURED_TEXT_PREFERENCE)}

        def sort_key(item: tuple[int, str]) -> tuple:
            roster_index, alias = item
            if alias in image_only:
                return (2, 0, 0.0, roster_index)
            if alias in measured:
                return (0, measured[alias], 0.0, roster_index)
            return (1, _alias_tier(alias), -_alias_version(alias), roster_index)

        ordered = sorted(enumerate(available_models), key=sort_key)
        return [alias for _, alias in ordered]

    def rank_for_stage(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> list[str]:
        """``ranked_models`` reordered for a stage: measured stage picks first.

        The explorer and the image reviewer have their own measured orders;
        fallbacks within a stage follow them rather than the solving order.
        """
        preference = {"explore": MEASURED_EXPLORE_PREFERENCE, "image_review": MEASURED_REVIEW_PREFERENCE}.get(stage, ())
        first = [alias for alias in preference if alias in ranked_models]
        return first + [alias for alias in ranked_models if alias not in first]

    def pick_model(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> str:
        """Stage-specific measured picks (tool loop, image review); the rest on rank."""
        if stage in {"explore", "image_review"}:
            ordered = self.rank_for_stage(stage, ranked_models, ctx)
            return ordered[0] if ordered else ""
        return super().pick_model(stage, ranked_models, ctx)

    def call_cap_s(self, model: str, ctx: ChallengeContext) -> float:
        """Seconds to wait for one direct call before handing over.

        Three times the model's measured p90, between 15 and 60 seconds, and
        half again for hard puzzles. Unmeasured models get the full 60.
        """
        measured = MEASURED_LATENCY_S.get(model)
        if measured is None:
            return 60.0
        cap = min(60.0, max(15.0, 3.0 * measured[1]))
        if str(ctx.difficulty or "").lower() == "hard":
            cap = min(60.0, cap * 1.5)
        return cap

    def typical_s(self, model: str) -> float:
        """A call to ``model`` usually finishes within this (measured p90; 20s unknown)."""
        measured = MEASURED_LATENCY_S.get(model)
        return measured[1] if measured else 20.0

    def on_time_warning(
        self,
        remaining_s: float,
        current_answer: str,
        ctx: ChallengeContext,
    ) -> str | None:
        """Last hook before a text submit: put list answers in canonical form."""
        _ = remaining_s
        return normalize_list_answer(current_answer, ctx.rules) or None

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Base prompt plus restated hard constraints and edit-scope guidance.

        The image judge scores constraint compliance separately; the baseline
        poster lost most of that axis to readable neon signs under "no text".
        """
        prompt = super().build_image_prompt(ctx)
        sections: list[str] = []
        constraints = image_constraint_lines(ctx)
        if constraints:
            sections.append(
                "Hard constraints (must hold everywhere in the image):\n"
                + "\n".join(f"- {line}" for line in constraints)
            )
        if ctx.image_url:
            sections.append(
                "Edit scope: change only what the instruction asks for. Keep the original "
                "composition, framing, subject identity, colors and lighting of everything "
                "else unchanged."
            )
        if not sections:
            return prompt
        return prompt + "\n\n" + "\n\n".join(sections)
