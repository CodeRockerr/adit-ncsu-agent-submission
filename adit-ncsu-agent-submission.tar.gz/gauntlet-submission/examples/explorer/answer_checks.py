"""Deterministic checks on a candidate text answer, and an exact order solver.

Checks only what can be decided from the puzzle text, so a failure comes with
a concrete reason the model can act on. Each clue is matched against a fixed
set of sentence templates and is then verified, violated, or unsupported. A
clue that fits no template is unsupported: never a violation, and never
counted as verified.

Dropping an unsupported clue only widens the set of orders that fit, so when
exactly one order fits the supported clues it is the answer, whatever the
other clues say, provided the set of names is right.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_ORDINALS = {
    "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6,
    "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10,
}
_NUMBER_WORDS = {
    "no": 0, "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}
# Orders the checker understands: earliest/leftmost first.
_NATURAL_ORDER_RE = re.compile(
    r"\b(?:order|sequence|line ?up|lineup|ranking|finish(?:ing)?|presentation|chronological|left[- ]to[- ]right|first to last|earliest to latest)\b",
    re.IGNORECASE,
)
_REVERSED_ORDER_RE = re.compile(
    r"\b(?:last to first|latest to earliest|right[- ]to[- ]left|descending|reverse)\b", re.IGNORECASE
)
# Asks for part of the order, so a short answer is not missing anyone.
_PARTIAL_RE = re.compile(
    r"\b(?:top|first|last|bottom|leading)\s+(?:\d+|two|three|four|five|six)\b|\bwho\b|\bwhich\b", re.IGNORECASE
)
_COUNT_RE = re.compile(r"\b(two|three|four|five|six|seven|eight|nine|ten|\d+)\s+(?!(?:times|minutes|seconds|hours|days|points|of)\b)[a-z]+", re.IGNORECASE)
_NAME_LIST_RE = re.compile(r"\b[A-Z][\w'-]*(?:\s*,\s*(?:and\s+)?[A-Z][\w'-]*){2,}(?:\s*,?\s*and\s+[A-Z][\w'-]*)?")

# Capitalized words that start sentences without being names.
_STOPWORDS = set(
    """a an the if then exactly neither either both each every no nobody none someone somebody only not there
    it he she they we you i in at on of for from to with between before after immediately directly just right who
    whoever when whenever unless one two three four five six seven eight nine ten first second third fourth fifth
    sixth seventh eighth ninth tenth last finally final also however moreover but and or nor clue clues note hint
    all some any among where what which while this that these those his her their its my our your somewhere
    nothing exactly determine find infer return order rank list arrange identify given based using use""".split()
)

# Template pieces, over a lowercase clue whose names are @1, @2.
_RESERVED = (
    r"not|never|no|nor|neither|either|or|and|but|if|then|unless|when|whenever|while|who|which|whom|whose|only|"
    r"both|all|each|every|same|before|after|ahead|behind|front|left|right|immediately|directly|just|somewhere|"
    r"sometime|precedes?|preceded|follows?|followed|next|adjacent|beside|alongside|between|exactly|least|most|"
    r"more|fewer|less|than|earlier|later|prior|sooner|apart|separated|consecutive|consecutively|neighbou?rs?|"
    r"neighbou?ring|from|except|also|too|by|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|"
    r"last|final|penultimate|places?|positions?|spots?|slots?|steps?|seats?|ranks?|zero|one|two|three|four|"
    r"five|six|seven|eight|nine|ten|\d+\w*|\w+n't|cannot"
)
_WORD = rf"(?!(?:{_RESERVED})\b)[a-z][a-z'-]*"
_FILL = rf"(?:{_WORD} ){{0,3}}"
_NEG = r"(?:not|never|\w+n't|cannot)"
_HEAD = rf"^@(?P<a>\d) {_FILL}(?:(?P<neg>{_NEG}) {_FILL})?"
_SOME = r"(?:(?:somewhere|sometime|anywhere|at some point) )?"
_IMM = r"(?P<imm>(?:immediately|directly|right|just) )?"
_BEFORE = r"(?:before|earlier than|sooner than|ahead of|in front of|to the left of|prior to|precedes|precede)"
_AFTER = r"(?:after|later than|behind|to the right of|follows|follow)"
_END = r"(?: (?:does|did|is|was|do))?$"
_NUM = r"(?:\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten)"
_PLACE = (
    r"(?:(?:second|next|third)[- ]to[- ]last|(?:second|third)[- ]last|penultimate|first|second|third|fourth|fifth|"
    r"sixth|seventh|eighth|ninth|tenth|last|final|\d+(?:st|nd|rd|th)|(?:position|place|spot|slot|number) ?#?\d+)"
)
_PLACES = rf"(?P<places>{_PLACE}(?:(?: or| nor)? (?:the )?{_PLACE})*)"
_TAIL_NOUN = rf"(?: (?:place|position|spot|slot))?(?: (?!(?:among|of|out|in|with|without|from|except)\b){_WORD})?(?: (?:to [a-z]+|in line|in the [a-z]+|overall))?$"

_TEMPLATES: list[tuple[str, re.Pattern]] = [
    ("passive", re.compile(
        r"^@(?P<a>\d) (?:is|was|are|were|gets|got|will be) (?:(?P<neg>not|never) )?(?P<imm1>(?:immediately|directly|right|just) )?"
        r"(?:(?P<pre>preceded)|(?P<fol>followed)) (?P<imm2>(?:immediately|directly|right|just) )?by @(?P<b>\d)" + _END
    )),
    ("inverted", re.compile(
        rf"^{_IMM}(?:(?P<bef>before)|(?P<aft>after)) @(?P<b>\d) (?:{_WORD} ){{1,2}}@(?P<a>\d)$"
    )),
    ("if_at", re.compile(
        rf"^if @(?P<a>\d) {_FILL}(?:in |at )?(?:the )?(?P<p>{_PLACE})(?: (?:place|position))? (?:then )?"
        rf"@(?P<b>\d) {_FILL}(?:in |at )?(?:the )?(?P<q>{_PLACE})(?: (?:place|position))?$"
    )),
    ("gap", re.compile(
        rf"^(?:there (?:is|are|was|were) )?(?:exactly )?(?P<k>{_NUM}|no one|nobody|no {_WORD}) (?:{_WORD} ){{0,3}}"
        rf"between @(?P<a>\d) and @(?P<b>\d)" + _END
    )),
    ("pair_adjacent", re.compile(
        rf"^@(?P<a>\d) and @(?P<b>\d) {_FILL}(?:(?P<neg>{_NEG}) {_FILL})?"
        r"(?:next to each other|adjacent(?: to each other)?|neighbou?rs|side by side|beside each other)(?: in line| in the [a-z]+)?$"
    )),
    ("adjacent", re.compile(rf"{_HEAD}{_SOME}(?:next to|adjacent to|beside|alongside) @(?P<b>\d)" + _END)),
    ("distance", re.compile(
        rf"{_HEAD}(?:exactly )?(?P<k>{_NUM}) (?:places?|spots?|positions?|steps?|seats?|ranks?) "
        rf"(?:(?P<bef>{_BEFORE})|(?P<aft>{_AFTER})) @(?P<b>\d)" + _END
    )),
    ("relation", re.compile(rf"{_HEAD}{_SOME}{_IMM}(?:(?P<bef>{_BEFORE})|(?P<aft>{_AFTER})) @(?P<b>\d)" + _END)),
    ("place_compare", re.compile(
        rf"{_HEAD}{_SOME}(?:(?P<bef>before|earlier than|ahead of)|(?P<aft>after|later than|behind)) (?:the )?(?P<place>{_PLACE})"
        + _TAIL_NOUN
    )),
    ("position", re.compile(rf"{_HEAD}(?P<either>(?:either|neither) )?(?:in |at )?(?:the )?{_PLACES}" + _TAIL_NOUN)),
]


@dataclass(frozen=True)
class Constraint:
    """One parsed clue over named items; positions are 1-based."""

    kind: str  # order, next, distance, adjacent, gap, at, before_place, after_place, if_at
    a: str
    b: str = ""
    k: int = 0
    places: tuple[str, ...] = ()
    negated: bool = False

    def holds(self, pos: dict[str, int], n: int) -> bool:
        pa = pos[self.a]
        pb = pos[self.b] if self.b else 0
        if self.kind == "order":
            result = pa < pb
        elif self.kind == "next":
            result = pa + 1 == pb
        elif self.kind == "distance":
            result = pb - pa == self.k
        elif self.kind == "adjacent":
            result = abs(pa - pb) == 1
        elif self.kind == "gap":
            result = abs(pa - pb) == self.k + 1
        elif self.kind == "at":
            result = pa in {_place_index(place, n) for place in self.places}
        elif self.kind == "before_place":
            result = pa < _place_index(self.places[0], n)
        elif self.kind == "after_place":
            result = pa > _place_index(self.places[0], n)
        elif self.kind == "if_at":
            result = pa != _place_index(self.places[0], n) or pb == _place_index(self.places[1], n)
        else:
            raise ValueError(self.kind)
        return not result if self.negated else result

    def names(self) -> tuple[str, ...]:
        return (self.a, self.b) if self.b else (self.a,)


@dataclass
class OrderCheck:
    """How an ordering answer fares against the clues."""

    order: list[str] = field(default_factory=list)
    verified: list[str] = field(default_factory=list)
    violated: list[str] = field(default_factory=list)
    unsupported: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    duplicates: list[str] = field(default_factory=list)

    @property
    def complete(self) -> bool:
        """Every clue was read and holds, and no name is missing or repeated."""
        return bool(self.verified) and not (self.violated or self.unsupported or self.missing or self.duplicates)


@dataclass
class OrderSolution:
    names: list[str] = field(default_factory=list)
    solutions: list[list[str]] = field(default_factory=list)
    constraints: list[Constraint] = field(default_factory=list)
    unsupported: list[str] = field(default_factory=list)
    reason: str = ""

    @property
    def unique(self) -> list[str] | None:
        return self.solutions[0] if len(self.solutions) == 1 else None


def split_list(answer: str) -> list[str]:
    return [item.strip().strip("`'\".") for item in str(answer or "").split(",") if item.strip()]


def unknown_list_items(answer: str, source: str) -> list[str]:
    """Items of a list answer that look invented: absent from the puzzle text.

    Only for answers drawn from a fixed set of names: most items must appear
    in the puzzle (so "red, blue" for a translation is not flagged).
    Numbers and computed values are never flagged.
    """
    items = split_list(answer)
    if len(items) < 2:
        return []
    lowered = source.lower()
    named = [item for item in items if re.search(r"[A-Za-z]", item)]
    missing = [item for item in named if item.lower() not in lowered]
    if not missing or len(named) - len(missing) < max(2, len(named) / 2):
        return []
    return missing


def is_ordering_task(description: str, rules: str) -> bool:
    text = f"{description} {rules}"
    return bool(_NATURAL_ORDER_RE.search(text)) and not _REVERSED_ORDER_RE.search(text)


def _number(token: str) -> int | None:
    token = token.lower().strip()
    if token.isdigit():
        return int(token)
    if token in {"no one", "nobody"} or token.startswith("no "):
        return 0
    return _NUMBER_WORDS.get(token)


def _place_index(place: str, n: int) -> int:
    place = place.lower().replace("-", " ")
    if place in {"last", "final"}:
        return n
    if place in {"second to last", "next to last", "second last", "penultimate"}:
        return n - 1
    if place in {"third to last", "third last"}:
        return n - 2
    if place in _ORDINALS:
        return _ORDINALS[place]
    digits = re.search(r"\d+", place)
    return int(digits.group(0)) if digits else 0


def _split_places(text: str) -> tuple[str, ...]:
    found = re.findall(_PLACE, text)
    return tuple(found)


def _placeholders(clue: str, names: list[str]) -> tuple[str, list[str]] | None:
    """The clue in lowercase with each named item replaced by @1, @2.

    A capitalized word right before a name ("Team Delta") is taken as part of
    it unless it is an ordinary sentence word. None for 3+ distinct names.
    """
    spans: list[tuple[int, int, str]] = []
    known = {name.lower() for name in names}
    for name in sorted(names, key=len, reverse=True):
        pattern = rf"(?<![\w@])(?:(?P<prefix>[A-Z][a-z]+)\s+)?(?i:{re.escape(name)})(?![\w])"
        for match in re.finditer(pattern, clue):
            start = match.start()
            prefix = match.group("prefix")
            if prefix and (prefix.lower() in _STOPWORDS or prefix.lower() in known):
                start = match.end() - len(name)
            if all(match.end() <= s or start >= e for s, e, _ in spans):
                spans.append((start, match.end(), name))
    ordered: list[str] = []
    for _, _, name in sorted(spans):
        if name not in ordered:
            ordered.append(name)
    if not ordered or len(ordered) > 2:
        return None
    out, last = [], 0
    for start, end, name in sorted(spans):
        out.append(clue[last:start].lower())
        out.append(f"@{ordered.index(name) + 1}")
        last = end
    out.append(clue[last:].lower())
    text = "".join(out)
    text = re.sub(r"^\s*(?:[-*•]\s*|(?:clue\s*)?\d+\s*[.):]\s*|clue\s*:\s*)", "", text)
    text = text.replace(",", " ").replace(";", " ")
    # "(not necessarily directly)" only says the clue is not an adjacency one.
    text = re.sub(r"\s*\(\s*(?:but )?not necessarily[^)]*\)", "", text)
    text = re.sub(r"\s+(?:but )?not necessarily (?:directly|immediately|right|adjacent)\W*$", "", text)
    text = re.sub(r"\s+", " ", text).strip().rstrip(".!").strip()
    return text, ordered


def parse_clue(clue: str, names: list[str]) -> Constraint | None:
    """The clue as a constraint over ``names``; None when no template fits."""
    found = _placeholders(clue, names)
    if found is None:
        return None
    text, ordered = found

    def name(group: str | None) -> str | None:
        if not group:
            return None
        index = int(group) - 1
        return ordered[index] if 0 <= index < len(ordered) else None

    for kind, pattern in _TEMPLATES:
        match = pattern.match(text)
        if not match:
            continue
        groups = match.groupdict()
        a, b = name(groups.get("a")), name(groups.get("b"))
        if a is None or (kind not in {"position", "place_compare"} and (b is None or a == b)):
            return None
        negated = bool(groups.get("neg"))
        if kind == "passive":
            immediate = bool(groups.get("imm1") or groups.get("imm2"))
            first, second = (b, a) if groups.get("pre") else (a, b)
            return Constraint("next" if immediate else "order", first, second, negated=negated)
        if kind == "if_at":
            return Constraint("if_at", a, b, places=(groups["p"], groups["q"]))
        if kind == "inverted":
            # "Before B comes A": A is before B.
            first, second = (a, b) if groups.get("bef") else (b, a)
            return Constraint("next" if groups.get("imm") else "order", first, second)
        if kind == "gap":
            k = _number(groups["k"])
            if k is None:
                return None
            return Constraint("adjacent", a, b) if k == 0 else Constraint("gap", a, b, k=k)
        if kind in {"pair_adjacent", "adjacent"}:
            return Constraint("adjacent", a, b, negated=negated)
        if kind == "distance":
            k = _number(groups["k"])
            if not k:
                return None
            first, second = (a, b) if groups.get("bef") else (b, a)
            return Constraint("distance", first, second, k=k, negated=negated)
        if kind == "relation":
            first, second = (a, b) if groups.get("bef") else (b, a)
            return Constraint("next" if groups.get("imm") else "order", first, second, negated=negated)
        if b is not None:
            return None  # a second name where only one belongs
        if kind == "place_compare":
            return Constraint("before_place" if groups.get("bef") else "after_place", a, places=(groups["place"],), negated=negated)
        places = _split_places(groups["places"])
        if not places:
            return None
        either = (groups.get("either") or "").strip()
        if either == "neither":
            negated = not negated
        return Constraint("at", a, places=places, negated=negated)
    return None


def clue_holds(clue: str, order: list[str]) -> bool | None:
    """Whether ``order`` satisfies ``clue``; None when the clue is not understood."""
    constraint = parse_clue(clue, list(order))
    if constraint is None:
        return None
    pos = {item: index + 1 for index, item in enumerate(order)}
    if any(name not in pos for name in constraint.names()):
        return None
    if constraint.places and any(
        _place_index(place, len(order)) < 1 or _place_index(place, len(order)) > len(order) for place in constraint.places
    ):
        return None
    return constraint.holds(pos, len(order))


# Names in the puzzle ---------------------------------------------------------


def _capitalized_names(texts: list[str], lowercase_words: set[str]) -> list[str]:
    names: list[str] = []
    matches = [match for text in texts for match in re.finditer(r"(?<![\w@])[A-Z][\w'-]*(?: [A-Z][\w'-]*)?", text)]
    for match in matches:
        phrase = match.group(0)
        words = phrase.split()
        while words and (words[0].lower() in _STOPWORDS or words[0].lower() in lowercase_words):
            words = words[1:]
        if len(words) == 2 and (words[1].lower() in _STOPWORDS or words[1].lower() in lowercase_words):
            words = words[:1]
        if not words:
            continue
        candidate = " ".join(words)
        if candidate not in names:
            names.append(candidate)
    return names


def extract_names(clues: list[str], description: str = "") -> tuple[list[str], int | None]:
    """(names in the clues and in any name list in the description, stated count)."""
    text = " ".join(clues)
    lowercase_words = set(re.findall(r"\b[a-z][\w'-]*\b", f"{text} {description}"))
    names = _capitalized_names([str(clue) for clue in clues], lowercase_words)
    for run in _NAME_LIST_RE.findall(description or ""):
        for name in re.findall(r"[A-Z][\w'-]*", run):
            if name.lower() not in _STOPWORDS and name not in names and not any(name in full.split() for full in names):
                names.append(name)
    # "Team Delta" and "Delta" are one name: keep the fuller form.
    names = [name for name in names if not any(other != name and other.endswith(" " + name) for other in names)]
    count_match = _COUNT_RE.search(description or "")
    count = _number(count_match.group(1)) if count_match else None
    return names, count


def _match_item(item: str, names: list[str]) -> str | None:
    lowered = item.strip().lower()
    for name in names:
        if lowered == name.lower() or (" " in name and lowered == name.split()[-1].lower()):
            return name
    return None


def order_items(answer: str, names: list[str]) -> list[str | None] | None:
    """The answer's items as puzzle names (None where an item is not one), or
    None unless most items are puzzle names: an attempt at the order."""
    items = split_list(answer)
    if len(items) < 2 or not names:
        return None
    mapped = [_match_item(item, names) for item in items]
    return mapped if sum(item is not None for item in mapped) >= max(2, len(items) / 2) else None


# Checks and solving -----------------------------------------------------------


def _clue_sentences(clues: list[str], description: str) -> list[str]:
    sentences = [part.strip() for part in re.split(r"(?<=[.!?])\s+", description or "") if part.strip()]
    return [str(clue) for clue in clues if str(clue).strip()] + sentences


def check_order(answer: str, clues: list[str], description: str = "", rules: str = "") -> OrderCheck | None:
    """Verify an ordering answer clue by clue; None when it is not an ordering task."""
    items = split_list(answer)
    if len(items) < 2 or not is_ordering_task(description, rules):
        return None
    names, count = extract_names(list(clues), description)
    mapped = [_match_item(item, names) for item in items]
    use_names = names if names and all(mapped) else list(dict.fromkeys(items))
    order = [m for m in mapped] if names and all(mapped) else items
    check = OrderCheck(order=list(order))
    seen: set[str] = set()
    for item in order:
        if item.lower() in seen and item not in check.duplicates:
            check.duplicates.append(item)
        seen.add(item.lower())
    if check.duplicates:
        return check
    pos = {item: index + 1 for index, item in enumerate(order)}
    n = len(order)
    confirmed: set[str] = set()
    for clue in clues:
        constraint = parse_clue(str(clue), use_names)
        if constraint is not None:
            confirmed.update(constraint.names())
        if constraint is None or any(name not in pos for name in constraint.names()):
            check.unsupported.append(str(clue))
        elif constraint.holds(pos, n):
            check.verified.append(str(clue))
        else:
            check.violated.append(str(clue))
    # Description sentences are mostly setup: only parsed ones count.
    for sentence in _clue_sentences([], description):
        constraint = parse_clue(sentence, use_names)
        if constraint is not None and all(name in pos for name in constraint.names()):
            (check.verified if constraint.holds(pos, n) else check.violated).append(sentence)
    partial = bool(_PARTIAL_RE.search(f"{description} {rules}"))
    if names and all(mapped) and not partial:
        # A name counts as missing when a supported clue uses it, or when the
        # description's count confirms the whole list.
        sure = set(names) if count == len(names) else confirmed
        check.missing = [name for name in names if name not in pos and name in sure]
    return check


def violated_clues(answer: str, clues: list[str], description: str = "", rules: str = "") -> list[str]:
    """Clues an ordering answer breaks; empty when none, or when not checkable."""
    check = check_order(answer, clues, description, rules)
    return check.violated if check else []


def solve_order(clues: list[str], description: str = "", rules: str = "", *, limit: int = 2, max_names: int = 9) -> OrderSolution:
    """Orders that satisfy every supported clue, up to ``limit``.

    Refuses (empty solutions, with a reason) when the names are uncertain:
    a stated count that disagrees, or a name no supported clue mentions.
    """
    result = OrderSolution()
    if not is_ordering_task(description, rules):
        result.reason = "not an ordering task"
        return result
    if _PARTIAL_RE.search(f"{description} {rules}"):
        result.reason = "asks for part of the order"
        return result
    names, count = extract_names(list(clues), description)
    result.names = names
    if not 2 <= len(names) <= max_names:
        result.reason = f"{len(names)} names"
        return result
    if count is not None and count != len(names):
        result.reason = f"description says {count}, clues name {len(names)}"
        return result
    for sentence in _clue_sentences(list(clues), description):
        constraint = parse_clue(sentence, names)
        if constraint is None:
            if sentence in clues:
                result.unsupported.append(sentence)
            continue
        if constraint.places and any(
            not 1 <= _place_index(place, len(names)) <= len(names) for place in constraint.places
        ):
            result.reason = f"position out of range in {sentence!r}"
            return result
        result.constraints.append(constraint)
    mentioned = {name for constraint in result.constraints for name in constraint.names()}
    if count is None and set(names) - mentioned:
        result.reason = "some names appear in no supported clue: " + ", ".join(sorted(set(names) - mentioned))
        return result
    solutions, finished = _search(names, result.constraints, limit)
    if not finished and len(solutions) < limit:
        # An unfinished search cannot rule out other orders (or prove none).
        result.reason = "search too large"
        return result
    result.solutions = solutions
    result.reason = {0: "no order fits the supported clues", 1: "unique"}.get(len(solutions), "several orders fit")
    return result


SEARCH_BUDGET = 40_000  # placements; a typical 8-name puzzle needs a few hundred


def _search(names: list[str], constraints: list[Constraint], limit: int) -> tuple[list[list[str]], bool]:
    """(orders found, whether the search finished): backtracking over positions,
    checking each constraint once its names are placed."""
    n = len(names)
    order: list[str] = []
    solutions: list[list[str]] = []
    pos: dict[str, int] = {}
    budget = [SEARCH_BUDGET]

    def ready(constraint: Constraint) -> bool:
        return all(name in pos for name in constraint.names())

    def extend() -> bool:
        if len(solutions) >= limit:
            return True
        if len(order) == n:
            solutions.append(list(order))
            return True
        for name in names:
            if name in pos:
                continue
            budget[0] -= 1
            if budget[0] < 0:
                return False
            pos[name] = len(order) + 1
            order.append(name)
            fine = all(c.holds(pos, n) for c in constraints if name in c.names() and ready(c))
            finished = extend() if fine else True
            order.pop()
            del pos[name]
            if not finished:
                return False
        return True

    finished = extend()
    return solutions, finished


def format_order(order: list[str], like: str = "") -> str:
    """``order`` as a comma list, short names when ``like`` used them."""
    items = split_list(like)
    short = bool(items) and all(" " not in item for item in items) and any(" " in name for name in order)
    return ", ".join(name.split()[-1] if short else name for name in order)
