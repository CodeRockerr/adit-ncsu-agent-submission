"""The explorer's view of the MCP server: discovery, model-facing specs, calls.

Tool descriptions may be empty and names may contain dots, which provider
function-calling APIs reject. The toolbox maps each MCP tool to a safe alias,
fills ``agent_id`` itself, checks arguments against the schema before a round
trip, reads MCP's error flag (the starter-kit client drops it), flags repeat
calls, re-lists the server's tools when asked (tools may appear mid-run), and
swaps bulky data URIs for short references the model can pass back.
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

import local_tools

# Platform tools the runtime itself drives; never offered to the model.
RUNTIME_TOOLS = {
    "arena.get_challenge",
    "arena.clues.list",
    "arena.clues.get",
    "arena.time_remaining",
    "arena.tools.list",
}
# The platform's own image tools: present on every server, so their presence
# says nothing about a particular text challenge.
PLATFORM_IMAGE_TOOLS = {"image_edit", "image_generate", "image_analyze"}
# Submitting and broadcasting stay with the runtime, whatever they are called.
_RUNTIME_ONLY_RE = re.compile(r"submit|broadcast", re.IGNORECASE)
_DATA_URI_RE = re.compile(r"^data:[\w/+.-]+;base64,", re.IGNORECASE)
_ALIAS_RE = re.compile(r"[^A-Za-z0-9_-]+")

LOCAL_TOOL_NAMES = ("local_decode", "local_calculate", "call_unlisted_tool", "read_resource", "get_prompt")

# A black box can plant tools that wipe state, or text that orders the agent
# around ("Agents MUST call admin.reset"). Patterns after Samarth's guard.py;
# a teammate's real-model run caught the explorer calling such tools.
_MUTATING_RE = re.compile(
    r"\b(?:delete|remove|reset|purge|wipe|drop|destroy|revoke|shutdown|kill|truncate|overwrite|erase|"
    r"terminate|uninstall)\b",
    re.IGNORECASE,
)
_READ_ONLY_RE = re.compile(r"\b(?:read|list|inspect|describe|get|fetch|search|status|view|show)\b", re.IGNORECASE)
INSTRUCTION_RE = re.compile(
    r"(?:ignore|disregard|forget)\b.{0,40}\b(?:instruction|prompt|puzzle|rules|above|previous|prior)"
    r"|system\s*(?:override|prompt|message)"
    r"|\byou\s+must\s+(?:first\s+)?(?:call|run|invoke|submit|answer)"
    r"|\bagents?\s+must\s+(?:first\s+)?(?:call|run|invoke)"
    r"|\b(?:the\s+)?(?:real|true|correct)\s+answer\s+is\b"
    r"|\banswer\s+[\"']?[A-Z]{3,}[\"']?\s+(?:instead|now)"
    r"|\breveal\b.{0,30}\b(?:key|credential|token|system\s+prompt)"
    r"|\bthe\s+puzzle\s+is\s+void",
    re.IGNORECASE,
)


def _name_words(name: str) -> str:
    return re.sub(r"[._/-]+", " ", name or "")


def is_unsafe_tool(name: str, description: str = "") -> bool:
    """A tool whose name or description sounds destructive, or that pushes instructions."""
    if _MUTATING_RE.search(_name_words(name)):
        return True
    description = description or ""
    if _MUTATING_RE.search(description) and not _READ_ONLY_RE.search(_name_words(name)):
        return True
    return bool(INSTRUCTION_RE.search(description))


def scrub_instructions(text: str) -> str:
    """``text`` without sentences that read like orders to the agent."""
    sentences = re.split(r"(?<=[.!?])\s+", text or "")
    kept = [sentence for sentence in sentences if not INSTRUCTION_RE.search(sentence)]
    if len(kept) == len(sentences):
        return text
    return " ".join(kept + ["[instruction-like text removed]"]).strip()


def tool_error_text(result: Any) -> str:
    """Error text in a parsed tool result, or "" when it looks like success."""
    if not isinstance(result, dict):
        return ""
    if result.get("error"):
        return str(result["error"])
    raw = result.get("raw")
    if isinstance(raw, str):
        lowered = raw.strip().lower()
        if lowered.startswith(("error executing tool", "unknown tool")):
            return raw.strip()
    return ""


@dataclass
class Outcome:
    ok: bool
    text: str
    result: Any = None
    cached: bool = False


@dataclass
class ServerExtras:
    """Non-tool MCP surfaces: resources, resource templates, prompts."""

    resources: list[dict[str, str]] = field(default_factory=list)
    templates: list[dict[str, str]] = field(default_factory=list)
    prompts: list[dict[str, Any]] = field(default_factory=list)

    def listing(self) -> str:
        lines = []
        for item in self.resources:
            lines.append(f"- resource {item['uri']} ({item.get('name') or 'unnamed'}) {item.get('description') or ''}".rstrip())
        for item in self.templates:
            lines.append(f"- resource template {item['uri']} {item.get('description') or ''}".rstrip())
        for item in self.prompts:
            args = ", ".join(item.get("arguments") or [])
            lines.append(f"- prompt {item['name']}({args}) {item.get('description') or ''}".rstrip())
        return "\n".join(lines)

    def __bool__(self) -> bool:
        return bool(self.resources or self.templates or self.prompts)


async def discover_extras(session: Any, timeout_s: float = 4.0) -> ServerExtras:
    """List resources, templates and prompts; servers without them return empty."""
    extras = ServerExtras()
    if session is None:
        return extras

    async def _list(method: str):
        try:
            return await asyncio.wait_for(getattr(session, method)(), timeout=timeout_s)
        except Exception:
            return None

    resources, templates, prompts = await asyncio.gather(
        _list("list_resources"), _list("list_resource_templates"), _list("list_prompts")
    )
    for item in getattr(resources, "resources", None) or []:
        extras.resources.append(
            {"uri": str(item.uri), "name": str(item.name or ""), "description": str(item.description or "")}
        )
    for item in getattr(templates, "resourceTemplates", None) or []:
        extras.templates.append(
            {"uri": str(item.uriTemplate), "name": str(item.name or ""), "description": str(item.description or "")}
        )
    for item in getattr(prompts, "prompts", None) or []:
        extras.prompts.append(
            {
                "name": str(item.name),
                "description": str(item.description or ""),
                "arguments": [str(arg.name) for arg in (item.arguments or [])],
            }
        )
    return extras


def _alias(name: str, taken: set[str]) -> str:
    base = _ALIAS_RE.sub("_", name).strip("_")[:60] or "tool"
    alias, suffix = base, 2
    while alias in taken:
        alias = f"{base[:57]}_{suffix}"
        suffix += 1
    taken.add(alias)
    return alias


def _schema_parts(tool_def: Any) -> tuple[dict, list[str]]:
    schema = getattr(tool_def, "inputSchema", None)
    if not isinstance(schema, dict):
        return {}, []
    properties = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
    required = [str(name) for name in schema.get("required") or [] if isinstance(name, str)]
    return properties, required


def _type_names(prop: dict) -> set[str]:
    kinds: set[str] = set()
    if isinstance(prop.get("type"), str):
        kinds.add(prop["type"])
    elif isinstance(prop.get("type"), list):
        kinds.update(str(kind) for kind in prop["type"])
    for option in prop.get("anyOf") or prop.get("oneOf") or []:
        if isinstance(option, dict) and isinstance(option.get("type"), str):
            kinds.add(option["type"])
    return kinds


def coerce_arguments(properties: dict, required: list[str], arguments: dict) -> tuple[dict, str]:
    """Fit model arguments to the schema; return (arguments, problem)."""
    missing = [name for name in required if name != "agent_id" and name not in arguments]
    if missing:
        wanted = ", ".join(f"{name}: {'/'.join(sorted(_type_names(properties.get(name, {})))) or 'any'}" for name in missing)
        return arguments, f"missing required argument(s): {wanted}"
    fixed = dict(arguments)
    for name, value in arguments.items():
        kinds = _type_names(properties.get(name) or {})
        if not kinds or not isinstance(value, str):
            continue
        text = value.strip()
        if "string" in kinds:
            continue
        if "integer" in kinds and re.fullmatch(r"-?\d+", text):
            fixed[name] = int(text)
        elif "number" in kinds and re.fullmatch(r"-?\d+(?:\.\d+)?", text):
            fixed[name] = float(text)
        elif "boolean" in kinds and text.lower() in {"true", "false"}:
            fixed[name] = text.lower() == "true"
        elif kinds & {"object", "array"}:
            try:
                fixed[name] = json.loads(text)
            except json.JSONDecodeError:
                pass
    return fixed, ""


class Toolbox:
    """MCP tools plus local helpers, exposed to the model as functions."""

    def __init__(
        self,
        mcp_client: Any,
        tool_defs: list[Any],
        *,
        agent_id: str,
        extras: ServerExtras | None = None,
        budget: Callable[[float], float] | None = None,
        call_timeout_s: float = 20.0,
        max_chars: int = 3000,
        hidden: set[str] | None = None,
        link: Any = None,
        lister: Callable[[], Awaitable[list[Any]]] | None = None,
        allowed: set[str] | None = None,
    ) -> None:
        self.mcp = mcp_client
        self.session = getattr(mcp_client, "_session", None)
        # An McpLink replaces a broken connection; without one, calls use mcp_client.
        self.link = link
        self.agent_id = agent_id
        self.extras = extras or ServerExtras()
        self.budget = budget
        self.call_timeout_s = call_timeout_s
        self.max_chars = max_chars
        # Re-lists the server's tools; None when the caller cannot.
        self.lister = lister
        self.hidden = set(hidden or ())
        # Tools the challenge itself names (required, or in its text) may be
        # called even when they sound destructive; others are withheld.
        self.allowed = set(allowed or ())
        self.withheld: list[str] = []
        self.defs: dict[str, Any] = {}
        self.alias_to_name: dict[str, str] = {}
        self.name_to_alias: dict[str, str] = {}
        self._taken = set(LOCAL_TOOL_NAMES)
        self._add_defs(tool_defs)
        self.called: list[str] = []  # MCP tool names attempted, in call order
        self.succeeded: list[str] = []  # MCP tool names that returned a non-error result
        self.log: list[dict[str, Any]] = []
        self._previous: dict[str, Outcome] = {}
        self._blobs: dict[str, str] = {}

    def _add_defs(self, tool_defs: list[Any]) -> list[str]:
        """Register tool definitions; return the model-visible names that are new."""
        added = []
        for item in tool_defs:
            name = str(getattr(item, "name", "") or "")
            if not name:
                continue
            known = name in self.defs
            self.defs[name] = item  # a schema may change between listings
            if known or name in RUNTIME_TOOLS or name in self.hidden or _RUNTIME_ONLY_RE.search(name):
                continue
            if self._unsafe(name):
                self.withheld.append(name)
                continue
            alias = _alias(name, self._taken)
            self.alias_to_name[alias] = name
            self.name_to_alias[name] = alias
            added.append(name)
        return added

    def _unsafe(self, name: str) -> bool:
        if name in self.allowed:
            return False
        return is_unsafe_tool(name, str(getattr(self.defs.get(name), "description", "") or ""))

    async def refresh(self, timeout_s: float = 3.0) -> list[str]:
        """Re-list the server's tools; return the model-visible names that appeared."""
        if self.lister is None:
            return []
        try:
            tool_defs = await asyncio.wait_for(self.lister(), timeout=timeout_s)
        except Exception:
            return []
        return self._add_defs(list(tool_defs or []))

    def describe(self, names: list[str]) -> str:
        """One line per tool: alias, parameters and description, for a model note."""
        lines = []
        for name in names:
            spec = self._mcp_spec(name)["function"]
            params = ", ".join(spec["parameters"]["properties"]) or "no parameters"
            lines.append(f"- {spec['name']}({params}): {spec['description'][:200]}")
        return "\n".join(lines)

    # Discovery views --------------------------------------------------------

    def capability_tools(self) -> list[str]:
        """Model-visible MCP tools (everything but the runtime's own)."""
        return list(self.name_to_alias)

    def unfamiliar_tools(self) -> list[str]:
        """Visible tools that are not standard platform tools."""
        return [
            name
            for name in self.name_to_alias
            if name not in PLATFORM_IMAGE_TOOLS and not name.startswith("arena.image.")
        ]

    def specs(self, order: list[str] | None = None) -> list[dict[str, Any]]:
        names = [name for name in (order or []) if name in self.name_to_alias]
        names += [name for name in self.name_to_alias if name not in names]
        specs = [self._mcp_spec(name) for name in names]
        specs.append(_LOCAL_DECODE_SPEC)
        specs.append(_LOCAL_CALCULATE_SPEC)
        specs.append(_UNLISTED_SPEC)
        if self.extras.resources or self.extras.templates:
            specs.append(_READ_RESOURCE_SPEC)
        if self.extras.prompts:
            specs.append(_GET_PROMPT_SPEC)
        return specs

    def _mcp_spec(self, name: str) -> dict[str, Any]:
        tool_def = self.defs[name]
        properties, required = _schema_parts(tool_def)
        visible = {key: _clean_property(value) for key, value in properties.items() if key != "agent_id"}
        description = str(getattr(tool_def, "description", "") or "").strip()
        if not description:
            description = "No description given; infer its purpose from the name and parameters."
        return {
            "type": "function",
            "function": {
                "name": self.name_to_alias[name],
                "description": f"Server tool `{name}`. {description}"[:1000],
                "parameters": {
                    "type": "object",
                    "properties": visible,
                    "required": [key for key in required if key in visible],
                },
            },
        }

    # Execution ---------------------------------------------------------------

    async def execute(self, alias: str, raw_arguments: str | dict | None) -> Outcome:
        """Run one model tool call by alias; never raises."""
        try:
            arguments = raw_arguments if isinstance(raw_arguments, dict) else json.loads(raw_arguments or "{}")
        except json.JSONDecodeError as exc:
            return Outcome(False, f"arguments are not valid JSON: {exc}")
        if not isinstance(arguments, dict):
            return Outcome(False, "arguments must be a JSON object")
        arguments = self._expand_refs(arguments)
        if alias == "local_decode":
            result = local_tools.decode(
                arguments.get("data", ""),
                arguments.get("scheme", "auto"),
                str(arguments.get("key", "") or ""),
                _int_or_none(arguments.get("shift")),
            )
            return self._local_outcome(alias, arguments, result)
        if alias == "local_calculate":
            return self._local_outcome(alias, arguments, local_tools.calculate(arguments.get("expression", "")))
        if alias == "read_resource":
            return await self._read_resource(str(arguments.get("uri", "")))
        if alias == "get_prompt":
            return await self._get_prompt(str(arguments.get("name", "")), arguments.get("arguments") or {})
        if alias == "call_unlisted_tool":
            name = str(arguments.get("name", "")).strip()
            inner = arguments.get("arguments") or {}
            if isinstance(inner, str):
                try:
                    inner = json.loads(inner)
                except json.JSONDecodeError:
                    return Outcome(False, "arguments must be a JSON object")
            if not name or not isinstance(inner, dict):
                return Outcome(False, "give the tool name and an arguments object")
            if _RUNTIME_ONLY_RE.search(name) or name in RUNTIME_TOOLS:
                return Outcome(False, f"{name} is handled by the runtime; do not call it")
            return await self.call(name, inner)
        name = self.alias_to_name.get(alias)
        if name is None:
            return Outcome(False, f"unknown tool {alias!r}; use one of the listed tools or call_unlisted_tool")
        return await self.call(name, arguments)

    async def call(self, name: str, arguments: dict, *, timeout_s: float | None = None) -> Outcome:
        """Call an MCP tool by its server name, with schema checks and caching."""
        tool_def = self.defs.get(name)
        if self._unsafe(name):
            return self._record(name, arguments, Outcome(False, "refused: this tool looks destructive or pushes instructions, and the challenge does not ask for it"))
        properties, required = _schema_parts(tool_def) if tool_def else ({}, [])
        arguments = {key: value for key, value in arguments.items() if key != "agent_id"}
        if tool_def is not None:
            arguments, problem = coerce_arguments(properties, required, arguments)
            if problem:
                return self._record(name, arguments, Outcome(False, f"not called: {problem}"))
        # Repeats run again: errors may be transient and tools may be stateful.
        key = f"{name}:{json.dumps(arguments, sort_keys=True, default=str)}"
        payload = dict(arguments)
        if tool_def is None or "agent_id" in properties:
            payload["agent_id"] = self.agent_id
        cap = timeout_s or self.call_timeout_s
        timeout = cap if self.budget is None else self.budget(cap)
        self.called.append(name)
        try:
            if self.link is not None:
                result, is_error = await self.link.call(
                    lambda client: self._raw_call_on(client, name, payload),
                    timeout_s=timeout,
                    reconnect_budget_s=min(20.0, timeout),
                )
            else:
                result, is_error = await asyncio.wait_for(self._raw_call(name, payload), timeout=timeout)
        except asyncio.TimeoutError:
            return self._record(name, arguments, Outcome(False, f"timed out after {timeout:.0f}s"))
        except Exception as exc:  # transport or protocol failure
            return self._record(name, arguments, Outcome(False, f"call failed: {type(exc).__name__}: {str(exc)[:200]}"))
        error = tool_error_text(result)
        if is_error or error:
            text = error or self.render(result)
            outcome = Outcome(False, f"error: {text[: self.max_chars]}", result)
        else:
            outcome = Outcome(True, self.render(result), result)
            self.succeeded.append(name)
        previous = self._previous.get(key)
        self._previous[key] = outcome
        if previous is not None and previous.text == outcome.text:
            outcome = Outcome(outcome.ok, f"(repeat call; same result as before)\n{outcome.text}", result, cached=True)
        return self._record(name, arguments, outcome)

    async def _raw_call(self, name: str, payload: dict) -> tuple[Any, bool]:
        return await self._raw_call_on(self.mcp, name, payload)

    @staticmethod
    async def _raw_call_on(client: Any, name: str, payload: dict) -> tuple[Any, bool]:
        """(parsed result, MCP isError flag) from the session, else the client."""
        session = getattr(client, "_session", None)
        if session is not None and hasattr(client, "_parse_result"):
            raw = await session.call_tool(name, payload)
            return client._parse_result(raw), bool(getattr(raw, "isError", False))
        return await client.call_tool(name, payload), False

    def _current_session(self) -> Any:
        if self.link is not None and self.link.client is not None:
            return getattr(self.link.client, "_session", None)
        return self.session

    async def _read_resource(self, uri: str) -> Outcome:
        session = self._current_session()
        if not uri or session is None:
            return Outcome(False, "give a resource uri")
        try:
            result = await asyncio.wait_for(session.read_resource(uri), timeout=self.call_timeout_s)
        except Exception as exc:
            return Outcome(False, f"read failed: {type(exc).__name__}: {str(exc)[:200]}")
        parts = []
        for content in getattr(result, "contents", None) or []:
            text = getattr(content, "text", None)
            parts.append(text if text is not None else f"<binary {getattr(content, 'mimeType', '')}>")
        self.called.append(f"resource:{uri}")
        return Outcome(True, self._truncate("\n".join(parts)))

    async def _get_prompt(self, name: str, arguments: dict) -> Outcome:
        session = self._current_session()
        if not name or session is None:
            return Outcome(False, "give a prompt name")
        try:
            result = await asyncio.wait_for(
                session.get_prompt(name, {k: str(v) for k, v in dict(arguments).items()}),
                timeout=self.call_timeout_s,
            )
        except Exception as exc:
            return Outcome(False, f"prompt failed: {type(exc).__name__}: {str(exc)[:200]}")
        parts = []
        for message in getattr(result, "messages", None) or []:
            content = getattr(message, "content", None)
            parts.append(str(getattr(content, "text", content)))
        return Outcome(True, self._truncate("\n".join(parts)))

    # Rendering -----------------------------------------------------------------

    def render(self, value: Any) -> str:
        return self._truncate(json.dumps(self._shrink(value), ensure_ascii=False, default=str))

    def shrink(self, value: Any) -> Any:
        """``value`` with data URIs and very long strings replaced by blob references."""
        return self._shrink(value)

    def _shrink(self, value: Any) -> Any:
        if isinstance(value, str) and (_DATA_URI_RE.match(value) or len(value) > 4000):
            ref = f"blob_{len(self._blobs) + 1}"
            self._blobs[ref] = value
            kind = "data URI" if _DATA_URI_RE.match(value) else "long text"
            return f"<{kind}, {len(value)} chars, stored as {ref}; pass \"{ref}\" as an argument to use it>"
        if isinstance(value, dict):
            return {key: self._shrink(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._shrink(item) for item in value]
        return value

    def _expand_refs(self, value: Any) -> Any:
        if isinstance(value, str) and value in self._blobs:
            return self._blobs[value]
        if isinstance(value, dict):
            return {key: self._expand_refs(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._expand_refs(item) for item in value]
        return value

    def _truncate(self, text: str) -> str:
        if len(text) <= self.max_chars:
            return text
        return text[: self.max_chars] + f"... [truncated {len(text) - self.max_chars} chars]"

    def _local_outcome(self, alias: str, arguments: dict, result: dict) -> Outcome:
        outcome = Outcome("error" not in result, self.render(result), result)
        self.log.append({"tool": alias, "arguments": _short(arguments), "ok": outcome.ok})
        return outcome

    def _record(self, name: str, arguments: dict, outcome: Outcome) -> Outcome:
        self.log.append({"tool": name, "arguments": _short(arguments), "ok": outcome.ok, "result": outcome.text[:300]})
        return outcome


def _short(arguments: dict) -> dict:
    return {key: (value[:120] + "...") if isinstance(value, str) and len(value) > 120 else value for key, value in arguments.items()}


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _clean_property(prop: Any) -> dict:
    """A JSON-schema property without titles/defaults that some providers reject."""
    if not isinstance(prop, dict):
        return {"type": "string"}
    cleaned = {key: value for key, value in prop.items() if key not in {"title", "default"}}
    if "anyOf" in cleaned:
        options = [option for option in cleaned["anyOf"] if isinstance(option, dict) and option.get("type") != "null"]
        if len(options) == 1:
            cleaned.pop("anyOf")
            cleaned.update(options[0])
    if not any(key in cleaned for key in ("type", "anyOf", "oneOf", "enum", "$ref")):
        cleaned["type"] = "string"
    return cleaned


_LOCAL_DECODE_SPEC = {
    "type": "function",
    "function": {
        "name": "local_decode",
        "description": (
            "Decode encoded or enciphered text locally. scheme 'auto' ranks likely decodings "
            "(including two layers, e.g. base64 then Caesar). Schemes: " + ", ".join(local_tools.SCHEMES)
            + ". vigenere and xor need key; caesar takes an optional shift (omit to try all)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "data": {"type": "string"},
                "scheme": {"type": "string", "enum": list(local_tools.SCHEMES)},
                "key": {"type": "string"},
                "shift": {"type": "integer"},
            },
            "required": ["data"],
        },
    },
}
_LOCAL_CALCULATE_SPEC = {
    "type": "function",
    "function": {
        "name": "local_calculate",
        "description": "Evaluate an arithmetic expression exactly (python syntax, math functions like sqrt, factorial, gcd, comb).",
        "parameters": {
            "type": "object",
            "properties": {"expression": {"type": "string"}},
            "required": ["expression"],
        },
    },
}
_UNLISTED_SPEC = {
    "type": "function",
    "function": {
        "name": "call_unlisted_tool",
        "description": (
            "Call a server tool by its exact name when it is mentioned somewhere (e.g. in a tool "
            "result) but is not in your tool list. agent_id is added for you."
        ),
        "parameters": {
            "type": "object",
            "properties": {"name": {"type": "string"}, "arguments": {"type": "object"}},
            "required": ["name"],
        },
    },
}
_READ_RESOURCE_SPEC = {
    "type": "function",
    "function": {
        "name": "read_resource",
        "description": "Read an MCP resource by URI (see the resources listed in the task).",
        "parameters": {"type": "object", "properties": {"uri": {"type": "string"}}, "required": ["uri"]},
    },
}
_GET_PROMPT_SPEC = {
    "type": "function",
    "function": {
        "name": "get_prompt",
        "description": "Fetch an MCP prompt by name, with its arguments.",
        "parameters": {
            "type": "object",
            "properties": {"name": {"type": "string"}, "arguments": {"type": "object"}},
            "required": ["name"],
        },
    },
}
