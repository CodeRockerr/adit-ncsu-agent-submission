"""An MCP connection that can be replaced mid-run.

The SSE transport does not fail pending requests when the stream breaks: the
error goes to the session's message handler and calls wait forever. A lobby
wait or a challenge would then hang until the heat is lost. McpLink owns the
connection in one task (anyio requires entering and exiting it in the same
task), flags transport errors, races every call against that flag and a
timeout, and reconnects once on failure. The reconnect contract allows this:
after GO, keep the identity, recreate the MCP context and continue.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Awaitable, Callable

from arena_clients import McpArenaClient, McpArenaError
from mcp import ClientSession
from mcp.client.sse import sse_client

RECONNECT_BUDGET_S = 20.0
_CLOSE_TIMEOUT_S = 5.0


class TransportBroken(ConnectionError):
    """The MCP connection failed and could not be replaced in time."""


class WatchedMcpClient(McpArenaClient):
    """McpArenaClient whose session reports transport errors to ``broken``."""

    def __init__(self, mcp_url: str | None, broken: asyncio.Event) -> None:
        super().__init__(mcp_url)
        self._broken = broken

    async def __aenter__(self) -> "WatchedMcpClient":
        self._context = sse_client(self.sse_url, headers=self._headers)
        read, write = await self._context.__aenter__()

        async def on_message(message: Any) -> None:
            # A late reply to a call we already timed out is harmless.
            if isinstance(message, Exception) and "unknown request id" not in str(message).lower():
                self._broken.set()

        self._session = ClientSession(read, write, message_handler=on_message)
        await self._session.__aenter__()
        await self._session.initialize()
        return self


def watched_client(mcp_url: str | None, broken: asyncio.Event) -> Any:
    return WatchedMcpClient(mcp_url, broken)


Opener = Callable[[asyncio.Event], Any]


class McpLink:
    """Owns the live MCP connection; ``call`` survives one transport failure."""

    def __init__(self, make_client: Opener, *, sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> None:
        self._make_client = make_client
        self._sleep = sleep
        self.client: Any = None
        self.broken = asyncio.Event()
        self.generation = 0
        self.reconnects = 0
        self._error: BaseException | None = None
        self._ready = asyncio.Event()
        self._wake = asyncio.Event()
        self._stop = False
        self._lock = asyncio.Lock()
        self._task: asyncio.Task | None = None
        self._budget_s = RECONNECT_BUDGET_S

    async def start(self, budget_s: float) -> Any:
        """Connect, retrying for up to ``budget_s``; returns the client."""
        self._budget_s = budget_s
        self._task = asyncio.create_task(self._run())
        await self._ready.wait()
        if self._error is not None:
            raise self._error
        return self.client

    async def _open(self, broken: asyncio.Event) -> tuple[Any, Any]:
        give_up_at = time.monotonic() + self._budget_s
        delay = 1.0
        while True:
            context = self._make_client(broken)
            try:
                return context, await context.__aenter__()
            except Exception as exc:
                try:
                    await context.__aexit__(type(exc), exc, None)
                except BaseException:
                    pass
                if time.monotonic() + delay > give_up_at:
                    raise
                print(f"   MCP connect failed ({type(exc).__name__}); retrying in {delay:.0f}s")
                await self._sleep(delay)
                delay = min(delay * 2, 10.0)

    async def _run(self) -> None:
        while not self._stop:
            broken = asyncio.Event()
            try:
                context, client = await self._open(broken)
            except Exception as exc:
                self._error = exc
                self._ready.set()
                return
            self.client, self.broken, self._error = client, broken, None
            self.generation += 1
            self._ready.set()
            try:
                await self._wake.wait()
            except asyncio.CancelledError:
                # The transport's task group cancels its host task when it fails.
                if self._stop:
                    raise
                broken.set()
            try:
                async with asyncio.timeout(_CLOSE_TIMEOUT_S):
                    await context.__aexit__(None, None, None)
            except BaseException:
                pass
            self._wake.clear()

    async def reconnect(self, seen_generation: int, budget_s: float = RECONNECT_BUDGET_S) -> Any:
        """Replace the connection unless another caller already did."""
        async with self._lock:
            if self.generation != seen_generation and self._error is None and not self.broken.is_set():
                return self.client
            print("   MCP connection lost; reconnecting...")
            self._budget_s = max(1.0, budget_s)
            self._ready.clear()
            self._wake.set()
            await self._ready.wait()
            if self._error is not None:
                raise TransportBroken(f"reconnect failed: {self._error!r}")
            self.reconnects += 1
            return self.client

    async def call(
        self,
        action: Callable[[Any], Awaitable[Any]],
        *,
        timeout_s: float,
        reconnect_budget_s: float = RECONNECT_BUDGET_S,
        retry: bool = True,
    ) -> Any:
        """``action(client)`` bounded by ``timeout_s``, reconnecting once on transport failure.

        A tool-level McpArenaError and a plain timeout propagate unchanged.
        """
        generation, client, broken = self.generation, self.client, self.broken
        task = asyncio.ensure_future(action(client))
        watcher = asyncio.ensure_future(broken.wait())
        try:
            done, _ = await asyncio.wait({task, watcher}, timeout=timeout_s, return_when=asyncio.FIRST_COMPLETED)
        finally:
            watcher.cancel()
        if task in done:
            exc = task.exception()
            if exc is None:
                return task.result()
            if isinstance(exc, (McpArenaError, asyncio.TimeoutError)) or not retry:
                raise exc
        else:
            task.cancel()
            if not done:
                raise asyncio.TimeoutError(f"MCP call timed out after {timeout_s:.0f}s")
            if not retry:
                raise TransportBroken("MCP connection broke during the call")
        await self.reconnect(generation, reconnect_budget_s)
        return await self.call(action, timeout_s=timeout_s, retry=False)

    async def close(self) -> None:
        self._stop = True
        self._wake.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=_CLOSE_TIMEOUT_S + 1)
            except BaseException:
                self._task.cancel()


class LinkedMcp:
    """McpArenaClient-shaped facade whose calls go through an McpLink."""

    def __init__(self, link: McpLink, timeout_s: float = 20.0) -> None:
        self.link = link
        self.timeout_s = timeout_s

    async def _call(self, method: str, *args: Any, timeout_s: float | None = None, **kwargs: Any) -> Any:
        return await self.link.call(
            lambda client: getattr(client, method)(*args, **kwargs),
            timeout_s=timeout_s or self.timeout_s,
        )

    async def list_tool_defs(self) -> list[Any]:
        return await self._call("list_tool_defs")

    async def get_challenge(self, agent_id: str):
        return await self._call("get_challenge", agent_id)

    async def get_image_challenge(self, agent_id: str):
        return await self._call("get_image_challenge", agent_id)

    async def list_clues(self, agent_id: str) -> list[str]:
        return await self._call("list_clues", agent_id)

    async def get_clue(self, clue_id: str, agent_id: str):
        return await self._call("get_clue", clue_id, agent_id)

    async def call_tool(self, name: str, arguments: dict) -> dict:
        return await self._call("call_tool", name, arguments)

    async def time_remaining(self, agent_id: str) -> dict:
        return await self._call("time_remaining", agent_id, timeout_s=10.0)

    async def submit_image(self, **kwargs: Any) -> dict:
        # An exact resubmission returns the original receipt, so a retry after
        # a reconnect is safe.
        return await self._call("submit_image", timeout_s=60.0, **kwargs)

    async def reconnect(self) -> None:
        await self.link.reconnect(self.link.generation)

    @property
    def _session(self) -> Any:
        return getattr(self.link.client, "_session", None)

    def _parse_result(self, raw: Any) -> Any:
        return self.link.client._parse_result(raw)
