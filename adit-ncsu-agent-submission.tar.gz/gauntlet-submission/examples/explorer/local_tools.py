"""Deterministic helpers the explorer offers the model as local tools.

Models are unreliable at character-level decoding and long arithmetic, so
these run locally: no tokens, no network, no code execution.
"""

from __future__ import annotations

import ast
import base64
import binascii
import math
import operator
import json
import re
import string
from typing import Any
from urllib.parse import unquote

MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F",
    "--.": "G", "....": "H", "..": "I", ".---": "J", "-.-": "K", ".-..": "L",
    "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R",
    "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X",
    "-.--": "Y", "--..": "Z", "-----": "0", ".----": "1", "..---": "2",
    "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7",
    "---..": "8", "----.": "9", ".-.-.-": ".", "--..--": ",", "..--..": "?",
    "-.-.--": "!", "-..-.": "/", "-....-": "-", ".--.-.": "@",
}

COMMON_WORDS = {
    "the", "and", "is", "of", "to", "a", "in", "it", "you", "that", "for", "on",
    "with", "this", "are", "be", "at", "or", "as", "your", "from", "key", "code",
    "password", "answer", "secret", "flag", "use", "call", "tool", "next", "find",
    "vault", "unlock", "open", "id", "hint", "clue", "message", "word", "number",
}

SCHEMES = (
    "auto", "base64", "base64url", "base32", "hex", "binary", "decimal", "octal",
    "rot13", "rot47", "caesar", "atbash", "reverse", "morse", "url", "a1z26",
    "vigenere", "xor",
)


def printable_ratio(text: str) -> float:
    if not text:
        return 0.0
    good = sum(1 for ch in text if ch in string.printable or ch.isalpha())
    return good / len(text)


def english_score(text: str) -> float:
    """Rough plain-English likelihood: common words plus letter/space share.

    Very short outputs score low, so a stray digit decoded to "A" cannot
    outrank a real sentence.
    """
    words = re.findall(r"[a-z]{2,}", text.lower())
    if not words:
        return 0.0
    hits = sum(1 for word in words if word in COMMON_WORDS)
    letters = sum(1 for ch in text if ch.isalpha() or ch == " ") / max(1, len(text))
    return (hits * 2.0 + letters) * min(1.0, len(text.strip()) / 12)


def _as_text(raw: bytes) -> str | None:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return None
    return text if text and printable_ratio(text) >= 0.95 else None


def _shift_letters(text: str, shift: int) -> str:
    out = []
    for ch in text:
        if "a" <= ch <= "z":
            out.append(chr((ord(ch) - 97 + shift) % 26 + 97))
        elif "A" <= ch <= "Z":
            out.append(chr((ord(ch) - 65 + shift) % 26 + 65))
        else:
            out.append(ch)
    return "".join(out)


def _b64(data: str, *, urlsafe: bool = False) -> str | None:
    compact = re.sub(r"\s+", "", data)
    compact += "=" * (-len(compact) % 4)
    try:
        raw = (
            base64.urlsafe_b64decode(compact)
            if urlsafe
            else base64.b64decode(compact, validate=True)
        )
    except (binascii.Error, ValueError):
        return None
    return _as_text(raw)


def _b32(data: str) -> str | None:
    compact = re.sub(r"\s+", "", data).upper()
    compact += "=" * (-len(compact) % 8)
    try:
        return _as_text(base64.b32decode(compact))
    except (binascii.Error, ValueError):
        return None


def _hex(data: str) -> str | None:
    compact = re.sub(r"[\s:]|0x", "", data, flags=re.IGNORECASE)
    try:
        return _as_text(bytes.fromhex(compact))
    except ValueError:
        return None


def _numbers(data: str, base: int) -> str | None:
    # Only data that is all numbers: digits inside other text are not a code.
    digits = "0-7" if base == 8 else "0-9"
    if not re.fullmatch(rf"[{digits}\s,;]+", data.strip()):
        return None
    tokens = re.findall(rf"[{digits}]+", data)
    if not tokens:
        return None
    try:
        raw = bytes(int(token, base) for token in tokens)
    except ValueError:
        return None
    return _as_text(raw)


def _binary(data: str) -> str | None:
    bits = re.sub(r"[^01]", "", data)
    if not bits or len(bits) % 8:
        return None
    return _as_text(bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)))


def _rot47(data: str) -> str:
    return "".join(
        chr(33 + (ord(ch) - 33 + 47) % 94) if 33 <= ord(ch) <= 126 else ch for ch in data
    )


def _atbash(data: str) -> str:
    out = []
    for ch in data:
        if "a" <= ch <= "z":
            out.append(chr(122 - (ord(ch) - 97)))
        elif "A" <= ch <= "Z":
            out.append(chr(90 - (ord(ch) - 65)))
        else:
            out.append(ch)
    return "".join(out)


def _morse(data: str) -> str | None:
    if not re.fullmatch(r"[.\-\s/|]+", data.strip()):
        return None
    words = re.split(r"\s*[/|]\s*|\s{3,}", data.strip())
    decoded = []
    for word in words:
        letters = [MORSE.get(symbol) for symbol in word.split()]
        if any(letter is None for letter in letters):
            return None
        decoded.append("".join(letters))
    return " ".join(decoded)


def _a1z26(data: str) -> str | None:
    if not re.fullmatch(r"[\d\s,;/|\-]+", data.strip()):
        return None
    words = re.split(r"\s*[/|]\s*|\s{2,}", data.strip())
    out = []
    for word in words:
        numbers = re.findall(r"\d+", word)
        if not numbers or any(not 1 <= int(n) <= 26 for n in numbers):
            return None
        out.append("".join(chr(64 + int(n)) for n in numbers))
    return " ".join(out)


def _vigenere(data: str, key: str) -> str | None:
    shifts = [ord(ch) - 97 for ch in key.lower() if ch.isalpha()]
    if not shifts:
        return None
    out, index = [], 0
    for ch in data:
        if ch.isalpha():
            out.append(_shift_letters(ch, -shifts[index % len(shifts)]))
            index += 1
        else:
            out.append(ch)
    return "".join(out)


def _xor(data: str, key: str) -> str | None:
    if not key:
        return None
    raw = None
    for parse in (
        lambda d: bytes.fromhex(re.sub(r"\s", "", d)),
        lambda d: base64.b64decode(re.sub(r"\s", "", d), validate=True),
    ):
        try:
            raw = parse(data)
            break
        except (ValueError, binascii.Error):
            continue
    if raw is None:
        raw = data.encode("utf-8")
    key_bytes: bytes
    if re.fullmatch(r"(?:0x)?[0-9a-fA-F]{2}", key):
        key_bytes = bytes([int(key.removeprefix("0x"), 16)])
    elif key.isdigit() and int(key) < 256:
        key_bytes = bytes([int(key)])
    else:
        key_bytes = key.encode("utf-8")
    return _as_text(bytes(b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(raw)))


def _single(scheme: str, data: str, key: str, shift: int | None) -> list[tuple[str, str]]:
    """Candidates (label, text) for one scheme; empty when it does not apply."""
    if scheme == "caesar":
        if shift is not None:
            return [(f"caesar shift {shift}", _shift_letters(data, -int(shift)))]
        return [(f"caesar shift {s}", _shift_letters(data, -s)) for s in range(1, 26)]
    simple = {
        "base64": lambda: _b64(data),
        "base64url": lambda: _b64(data, urlsafe=True),
        "base32": lambda: _b32(data),
        "hex": lambda: _hex(data),
        "binary": lambda: _binary(data),
        "decimal": lambda: _numbers(data, 10),
        "octal": lambda: _numbers(data, 8),
        "rot13": lambda: _shift_letters(data, 13),
        "rot47": lambda: _rot47(data),
        "atbash": lambda: _atbash(data),
        "reverse": lambda: data[::-1],
        "morse": lambda: _morse(data),
        "url": lambda: unquote(data) if "%" in data else None,
        "a1z26": lambda: _a1z26(data),
        "vigenere": lambda: _vigenere(data, key),
        "xor": lambda: _xor(data, key),
    }
    decoder = simple.get(scheme)
    if decoder is None:
        return []
    text = decoder()
    return [(scheme, text)] if text and text != data else []


# Layers "auto" tries without a key; text ciphers come last because they
# always "succeed" and only the English score can rank them.
_AUTO_LAYERS = ("base64", "base64url", "base32", "hex", "binary", "decimal", "morse", "a1z26", "url")
_AUTO_TEXT = ("rot13", "atbash", "reverse", "caesar")


def decode(data: str, scheme: str = "auto", key: str = "", shift: int | None = None) -> dict[str, Any]:
    """Decode ``data`` with one scheme, or rank likely decodings with "auto"."""
    data = str(data or "").strip()
    scheme = str(scheme or "auto").strip().lower()
    if not data:
        return {"error": "data is empty"}
    if scheme not in SCHEMES:
        return {"error": f"unknown scheme {scheme!r}; use one of: {', '.join(SCHEMES)}"}
    if scheme != "auto":
        candidates = _single(scheme, data, key, shift)
        if not candidates:
            return {"error": f"{scheme} does not decode this data"}
        ranked = sorted(candidates, key=lambda item: english_score(item[1]), reverse=True)
        return {"candidates": [{"scheme": label, "text": text} for label, text in ranked[:5]]}

    found: list[tuple[str, str]] = []
    for layer in _AUTO_LAYERS:
        for label, text in _single(layer, data, key, shift):
            found.append((label, text))
            # One more layer underneath, e.g. base64 wrapping a Caesar text.
            for inner in _AUTO_LAYERS + _AUTO_TEXT:
                for inner_label, inner_text in _single(inner, text, key, shift):
                    found.append((f"{label} > {inner_label}", inner_text))
    for layer in _AUTO_TEXT:
        found.extend(_single(layer, data, key, shift))
    if not found:
        return {"error": "no known encoding matched; try a specific scheme with a key"}
    ranked = sorted(found, key=lambda item: english_score(item[1]), reverse=True)
    seen: set[str] = set()
    best = []
    for label, text in ranked:
        if text in seen:
            continue
        seen.add(text)
        best.append({"scheme": label, "text": text[:2000]})
        if len(best) == 5:
            break
    return {"candidates": best}


_CLUE_META = {"clue_id", "id", "time_remaining_s", "agent_id"}
_SCHEME_ALIASES = {
    "b64": "base64", "base-64": "base64", "hexadecimal": "hex", "rot-13": "rot13", "reversed": "reverse",
    "backwards": "reverse", "base-32": "base32", "b32": "base32",
}


def _part_index(part: Any, position: int) -> int:
    if isinstance(part, dict):
        for key in ("i", "index", "part", "n", "seq", "order"):
            try:
                return int(part[key])
            except (KeyError, TypeError, ValueError):
                continue
    return position


def readable_clue(data: Any) -> str:
    """A clue result as plain text.

    Decodes a payload that declares its encoding, reassembles one sent in
    numbered parts, and reverses text a note says was sent backwards. A clue
    that cannot be read is returned as JSON so the model still sees it.
    """
    if isinstance(data, str):
        return data.strip()
    if not isinstance(data, dict):
        return str(data or "").strip()
    text = str(data.get("text") or "").strip()
    encoding = str(data.get("encoding") or data.get("scheme") or "").strip().lower()
    encoding = _SCHEME_ALIASES.get(encoding, encoding)
    payload = data.get("payload", data.get("data"))
    parts = data.get("parts")
    if isinstance(parts, list) and parts:
        ordered = sorted(enumerate(parts), key=lambda item: _part_index(item[1], item[0]))
        payload = "".join(
            str(part.get("data") or part.get("payload") or part.get("text") or "") if isinstance(part, dict) else str(part)
            for _, part in ordered
        )
    if payload not in (None, "") and (encoding or not text):
        decoded = decode(str(payload), encoding if encoding in SCHEMES else "auto")
        candidates = decoded.get("candidates") or []
        if candidates and english_score(candidates[0]["text"]) > english_score(str(payload)):
            text = str(candidates[0]["text"]).strip()
        elif not text:
            text = str(payload).strip()
    note = str(data.get("note") or data.get("hint") or "").lower()
    if text and re.search(r"\b(?:backwards?|reversed?|in reverse)\b", note):
        text = text[::-1].strip()
    if text:
        return text
    rest = {key: value for key, value in data.items() if key not in _CLUE_META}
    return json.dumps(rest, ensure_ascii=False, default=str) if rest else ""


_BLOB_PATTERNS = (
    ("base64", re.compile(r"(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{16,}={0,2}(?![A-Za-z0-9+/=])")),
    ("hex", re.compile(r"(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{2}){6,}(?![0-9A-Fa-f])")),
    ("binary", re.compile(r"(?:[01]{8}[\s]?){3,}")),
    ("morse", re.compile(r"(?:[.\-]{1,6}(?:\s+|\s*/\s*)){4,}[.\-]{1,6}")),
)


def decode_hints(texts: list[str], limit: int = 5) -> list[str]:
    """Readable decodings of encoded-looking blobs found in challenge text."""
    hints: list[str] = []
    seen: set[str] = set()
    for text in texts:
        for scheme, pattern in _BLOB_PATTERNS:
            for match in pattern.finditer(str(text or "")):
                blob = match.group(0).strip()
                if blob in seen:
                    continue
                seen.add(blob)
                # A plain long word also matches the base64 pattern.
                if scheme == "base64" and blob.isalpha() and (blob.islower() or blob.isupper()):
                    continue
                result = decode(blob, scheme)
                candidates = result.get("candidates") or []
                if not candidates:
                    continue
                # Look one layer further for text ciphers (e.g. base64 of ROT13).
                deeper = decode(candidates[0]["text"], "auto").get("candidates") or []
                best = max(candidates[:1] + deeper[:1], key=lambda c: english_score(c["text"]))
                label = scheme if best is candidates[0] else f"{scheme} > {best['scheme']}"
                if english_score(best["text"]) < 1.0:
                    continue
                hints.append(f"{blob[:60]} -> {best['text'][:200]!r} (decoded as {label})")
                if len(hints) >= limit:
                    return hints
    return hints


_BIN_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.BitXor: operator.xor, ast.BitAnd: operator.and_,
    ast.BitOr: operator.or_, ast.LShift: operator.lshift, ast.RShift: operator.rshift,
}
_UNARY_OPS = {ast.UAdd: operator.pos, ast.USub: operator.neg, ast.Invert: operator.invert}
_CMP_OPS = {
    ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt,
    ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
}
_FUNCTIONS = {
    name: getattr(math, name)
    for name in (
        "sqrt", "isqrt", "factorial", "gcd", "lcm", "comb", "perm", "log", "log2",
        "log10", "exp", "sin", "cos", "tan", "floor", "ceil", "fabs", "pi", "e",
    )
}
_FUNCTIONS.update({"abs": abs, "round": round, "min": min, "max": max, "sum": sum, "len": len, "int": int, "float": float})


def calculate(expression: str) -> dict[str, Any]:
    """Evaluate arithmetic safely: numbers, operators, comparisons, math functions."""
    expression = str(expression or "").strip()
    if not expression or len(expression) > 500:
        return {"error": "expression must be 1-500 characters"}
    try:
        tree = ast.parse(expression, mode="eval")
        return {"result": _evaluate(tree.body)}
    except ZeroDivisionError:
        return {"error": "division by zero"}
    except (ValueError, TypeError, SyntaxError, OverflowError) as exc:
        return {"error": f"cannot evaluate: {exc}"}


def _evaluate(node: ast.AST) -> Any:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
        left, right = _evaluate(node.left), _evaluate(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 10_000:
            raise ValueError("exponent too large")
        return _BIN_OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
        return _UNARY_OPS[type(node.op)](_evaluate(node.operand))
    if isinstance(node, ast.Compare) and all(type(op) in _CMP_OPS for op in node.ops):
        left = _evaluate(node.left)
        for op, comparator in zip(node.ops, node.comparators):
            right = _evaluate(comparator)
            if not _CMP_OPS[type(op)](left, right):
                return False
            left = right
        return True
    if isinstance(node, (ast.List, ast.Tuple)):
        return [_evaluate(item) for item in node.elts]
    if isinstance(node, ast.Name) and node.id in _FUNCTIONS and not callable(_FUNCTIONS[node.id]):
        return _FUNCTIONS[node.id]
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and callable(_FUNCTIONS.get(node.func.id))
        and not node.keywords
    ):
        return _FUNCTIONS[node.func.id](*[_evaluate(arg) for arg in node.args])
    raise ValueError(f"unsupported syntax: {ast.dump(node)[:80]}")
