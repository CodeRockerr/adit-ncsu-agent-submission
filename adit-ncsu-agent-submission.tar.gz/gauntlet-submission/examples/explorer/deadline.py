"""Challenge clock for the explorer agent.

The server's ``time_remaining_s`` at challenge fetch fixes the end; a reserve
at the end is kept free for the submit.
"""

from __future__ import annotations

import time
from typing import Callable

# Seconds kept free for the final submit: at least this, or this share of the
# challenge's time limit when that is larger.
RESERVE_MIN_S = 4.0
RESERVE_FRACTION = 0.06


class Deadline:
    """A monotonic end time with a submit reserve."""

    def __init__(
        self,
        seconds_left: float,
        max_time_s: float = 0.0,
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._clock = clock
        seconds_left = max(0.0, float(seconds_left or 0.0))
        self.max_time_s = float(max_time_s or seconds_left or 60.0)
        self.reserve_s = max(RESERVE_MIN_S, RESERVE_FRACTION * self.max_time_s)
        self.ends_at = clock() + seconds_left

    def left(self) -> float:
        """Seconds until the challenge ends."""
        return self.ends_at - self._clock()

    def work_left(self) -> float:
        """Seconds of work left before the submit reserve."""
        return self.left() - self.reserve_s

    def budget(self, cap_s: float, floor_s: float = 2.0) -> float:
        """A per-call timeout: at most ``cap_s`` and never past the reserve."""
        return max(floor_s, min(cap_s, self.work_left()))
