#!/usr/bin/env python3
"""Explorer agent for Agent Gauntlet.

Built for unfamiliar MCP servers: it discovers tools, resources and prompts
before the challenge timer starts, then solves text challenges directly when
nothing calls for tools, or with a model-driven tool loop when something
does. Image challenges are produced, self-reviewed, and retried once.

Usage:
    cd examples/explorer
    python agent.py
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

from dotenv import load_dotenv

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent.parent
for _path in (str(REPO_ROOT), str(HERE)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

load_dotenv(REPO_ROOT / ".env")

from arena_clients import (  # noqa: E402
    ArenaAPIError,
    ArenaConnectionError,
    ChallengeInfo,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.config import agent_id_problem  # noqa: E402
from arena_clients.display import challenge_record, print_challenge, save_run_record  # noqa: E402
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines  # noqa: E402
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope  # noqa: E402
from base_strategy import ChallengeContext  # noqa: E402
from model_selector import ModelSelectionError, fetch_available_models, require_available_models  # noqa: E402
from my_strategy import MyStrategy  # noqa: E402

from deadline import Deadline  # noqa: E402
from image_solver import ImageSolver, image_context  # noqa: E402
from local_tools import decode_hints, readable_clue  # noqa: E402
from mcp_link import LinkedMcp, McpLink, TransportBroken, watched_client  # noqa: E402
from mcp_toolbox import ServerExtras, Toolbox, discover_extras, scrub_instructions, tool_error_text  # noqa: E402
from text_solver import TextSolver, extra_fields  # noqa: E402

try:
    from openai import AsyncOpenAI
except ImportError:  # reported at startup
    AsyncOpenAI = None

# The server may report the other modality; allow one switch each way.
MAX_MODALITY_SWITCHES = 2
SUBMIT_ATTEMPTS = 3
# Lobby: how often to ask for the challenge until GO (speed is timed from GO).
LOBBY_POLL_S = 0.5
# A clue that errors or is rate limited is fetched again, with growing pauses.
CLUE_ATTEMPTS = 3
CLUE_RETRY_S = 0.4
# Start-up runs before the challenge timer, so a server hiccup is worth
# waiting out: the organizer launches the agent once per heat.
STARTUP_RETRY_S = 180.0
_TRANSIENT_STARTUP_RE = re.compile(r"could not reach|\(HTTP 5\d\d\)|invalid validation response", re.IGNORECASE)
_TERMINAL_REGISTRATION_RE = re.compile(r"registration is closed|did not open within", re.IGNORECASE)
# Lobby polling gives up after this many failed reconnects in a row.
MAX_LOBBY_FAILURES = 10
# Builds the MCP client the link connects; tests replace it.
make_mcp_client = watched_client


def _is_transient_startup_error(exc: BaseException) -> bool:
    if isinstance(exc, SystemExit):  # ensure_connected reports through SystemExit
        return bool(_TRANSIENT_STARTUP_RE.search(str(exc.code or "")))
    if isinstance(exc, ArenaAPIError):
        return exc.status_code >= 500
    if isinstance(exc, ArenaConnectionError):
        return not _TERMINAL_REGISTRATION_RE.search(str(exc))
    return False


def with_startup_retries(step: str, action, *, budget_s: float = STARTUP_RETRY_S, sleep=time.sleep):
    """Run a start-up step, retrying transient network/server failures."""
    give_up_at = time.monotonic() + budget_s
    delay = 2.0
    while True:
        try:
            return action()
        except (SystemExit, ArenaAPIError, ArenaConnectionError) as exc:
            if not _is_transient_startup_error(exc) or time.monotonic() + delay > give_up_at:
                raise
            print(f"   {step} failed ({str(getattr(exc, 'code', None) or exc)[:120]}); retrying in {delay:.0f}s")
            sleep(delay)
            delay = min(delay * 2, 20.0)


class Reporter:
    """Thoughts and drafts for the spectator feed.

    Thoughts go out on background threads so the solve never waits on a round
    trip; ``ensure_one`` before submit secures the broadcast minimum.
    """

    def __init__(self, http_client, agent_id: str) -> None:
        self.http = http_client
        self.agent_id = agent_id
        self.sent = 0
        self._lock = threading.Lock()
        self._threads: list[threading.Thread] = []

    def _post(self, text: str) -> None:
        try:
            self.http.broadcast_thought(self.agent_id, text)
        except Exception:
            return
        with self._lock:
            self.sent += 1

    def think(self, text: str) -> None:
        text = str(text).strip()[:300]
        if not text:
            return
        print(f"   💭 {text}")
        thread = threading.Thread(target=self._post, args=(text,), daemon=True)
        thread.start()
        self._threads.append(thread)

    def ensure_one(self, timeout_s: float = 2.0) -> None:
        """Before submit: wait briefly for a thought to land, else post one now."""
        give_up_at = time.monotonic() + timeout_s
        for thread in list(self._threads):
            if self.sent:
                return
            thread.join(max(0.0, give_up_at - time.monotonic()))
        if not self.sent:
            self._post("Submitting final answer.")

    def draft(self, answer: str, rationale: str = "candidate answer") -> None:
        def _save() -> None:
            try:
                self.http.save_draft(self.agent_id, answer, rationale)
            except Exception:
                pass

        threading.Thread(target=_save, daemon=True).start()


def _wrong_modality_target(message: str, modality: str) -> str:
    lowered = message.lower()
    if modality == "text" and "image challenge" in lowered:
        return "image"
    if modality == "image" and ("not_image_challenge" in lowered or "text challenge" in lowered):
        return "text"
    return ""


def _alternate_challenge_tool(tool_names: list[str]) -> str:
    """Another text-challenge tool when the platform name is missing."""
    for name in tool_names:
        lowered = name.lower()
        if "challenge" in lowered and not re.search(r"image|submit|broadcast", lowered) and name != "arena.get_challenge":
            return name
    return ""


def _challenge_info(data: dict) -> ChallengeInfo:
    """A ChallengeInfo from an arbitrary challenge payload."""
    description = data.get("description") or data.get("question") or data.get("prompt") or data.get("task")
    return ChallengeInfo(
        challenge_type=str(data.get("challenge_type") or "text"),
        challenge_id=str(data.get("challenge_id") or ""),
        puzzle_id=str(data.get("puzzle_id") or ""),
        description=str(description or json.dumps(data, default=str)[:2000]),
        rules=str(data.get("rules") or data.get("format") or ""),
        max_time_s=int(data.get("max_time_s") or 0),
        clues=McpArenaClient._normalize_clues(data.get("clues")),
        time_remaining_s=float(data.get("time_remaining_s") or 0),
        raw_data=dict(data),
    )


async def fetch_challenge(mcp_client, agent_id: str, modality: str, tool_names: list[str] | None = None):
    """Wait out the lobby, then fetch the challenge for the server's real modality."""
    switches = 0
    failures = 0
    while True:
        try:
            if modality == "image":
                return modality, await mcp_client.get_image_challenge(agent_id)
            challenge = await mcp_client.get_challenge(agent_id)
            error = tool_error_text(getattr(challenge, "raw_data", None))
            if error:
                raise McpArenaError(error)
            return modality, challenge
        except McpArenaError as exc:
            message = str(exc)
            lowered = message.lower()
            if "locked" in lowered or "waiting for organizer" in lowered:
                print("   Lobby open; waiting for organizer to start battle...")
                await asyncio.sleep(LOBBY_POLL_S)
                continue
            alternate = _alternate_challenge_tool(tool_names or []) if "unknown tool" in lowered else ""
            if alternate and modality == "text":
                print(f"   arena.get_challenge is missing; using {alternate}.")
                data = await mcp_client.call_tool(alternate, {"agent_id": agent_id})
                error = tool_error_text(data)
                if error:
                    raise McpArenaError(error) from exc
                return modality, _challenge_info(data)
            target = _wrong_modality_target(message, modality)
            if modality == "image" and getattr(exc, "is_terminal", False):
                target = "text"
            if not target or switches >= MAX_MODALITY_SWITCHES:
                raise
            switches += 1
            print(f"   Server reports a {target} challenge; switching flows.")
            modality = target
        except (asyncio.TimeoutError, TransportBroken) as exc:
            # A lobby wait can be long; a dead connection must not end it.
            failures += 1
            if failures > MAX_LOBBY_FAILURES or not hasattr(mcp_client, "reconnect"):
                raise
            print(f"   Challenge fetch failed ({type(exc).__name__}); reconnecting.")
            try:
                await mcp_client.reconnect()
            except TransportBroken:
                await asyncio.sleep(2.0)


async def _read_clue(mcp_client, clue_id: str, agent_id: str) -> str:
    """One clue as plain text, retried when the tool fails or is rate limited."""
    for attempt in range(CLUE_ATTEMPTS):
        try:
            data = await mcp_client.call_tool("arena.clues.get", {"clue_id": clue_id, "agent_id": agent_id})
            if not tool_error_text(data):
                return readable_clue(data)
        except Exception:  # a dropped call is retried like an error result
            pass
        if attempt + 1 < CLUE_ATTEMPTS:
            await asyncio.sleep(CLUE_RETRY_S * (attempt + 1))
    return ""


async def read_clues(mcp_client, agent_id: str, challenge, tool_names: list[str]):
    """(clues, tools called, server seconds left) with the calls made concurrently."""
    called = {"arena.get_challenge"}

    async def _clues() -> list[str]:
        if "arena.clues.list" not in tool_names:
            return []
        clue_ids = await mcp_client.list_clues(agent_id)
        called.add("arena.clues.list")
        if not clue_ids:
            return []
        clues = await asyncio.gather(*(_read_clue(mcp_client, clue_id, agent_id) for clue_id in clue_ids))
        called.add("arena.clues.get")
        return [clue for clue in clues if clue]

    async def _time_left() -> tuple[float, float] | None:
        """(server seconds left, monotonic time the answer arrived)."""
        if "arena.time_remaining" not in tool_names:
            return None
        info = await mcp_client.time_remaining(agent_id)
        called.add("arena.time_remaining")
        if info.get("time_remaining_s") is None:
            return None
        return float(info["time_remaining_s"]), time.monotonic()

    clues_result, time_result = await asyncio.gather(_clues(), _time_left(), return_exceptions=True)
    clues = clues_result if isinstance(clues_result, list) else []
    if isinstance(clues_result, BaseException):
        print(f"   Clue tools failed ({type(clues_result).__name__}); using the challenge's own clues.")
    if not clues:
        clues = [str(clue) for clue in challenge.clues if str(clue).strip()]
    seconds_left = time_result if isinstance(time_result, tuple) else None
    return clues, called, seconds_left


def submit_with_retry(http_client, **submit_kwargs):
    """REST submit; a lost response is retried with the identical answer."""
    for attempt in range(1, SUBMIT_ATTEMPTS + 1):
        try:
            return http_client.submit(**submit_kwargs)
        except (ArenaConnectionError, ArenaAPIError) as exc:
            transient = isinstance(exc, ArenaConnectionError) or exc.status_code >= 500
            if not transient or attempt == SUBMIT_ATTEMPTS:
                raise
            print(f"   Submit response lost ({type(exc).__name__}); retrying the same answer.")
            time.sleep(0.5 * attempt)


def _required_tool_arguments(tool_def, hint: str) -> list[dict]:
    """Argument sets to try for a required tool: schema-built, then bare."""
    schema = getattr(tool_def, "inputSchema", None) or {}
    properties = schema.get("properties") or {}
    built = {
        name: hint
        for name in schema.get("required") or []
        if name != "agent_id" and (properties.get(name) or {}).get("type", "string") == "string"
    }
    return [built] if not built else [built, {}]


def _named_tools(text: str, tool_defs: list) -> set[str]:
    """Server tools the challenge text itself mentions by name."""
    return {str(tool.name) for tool in tool_defs if str(tool.name) and str(tool.name) in text}


async def _relist_tools(mcp, timeout_s: float = 4.0) -> list:
    """The server's tools now; empty on any failure (the earlier list stands)."""
    try:
        return list(await asyncio.wait_for(mcp.list_tool_defs(), timeout=timeout_s))
    except Exception:
        return []


async def play_text(*, mcp, http, strategy, reporter, agent_id, challenge, tool_defs, tool_names, extras, models, deadline, llm_host, api_key):
    reporter.think("Reading challenge and clues...")
    (clues, called, server_left), usage_scope, relisted = await asyncio.gather(
        read_clues(mcp, agent_id, challenge, tool_names),
        asyncio.to_thread(http.fetch_usage_scope),
        _relist_tools(mcp),
    )
    if relisted:
        # A server may reveal tools only once a challenge is assigned.
        known = {str(tool.name) for tool in tool_defs}
        tool_defs = list(tool_defs) + [tool for tool in relisted if str(tool.name) not in known]
    if server_left is not None:
        # Age the server's answer by the time since it arrived, and never let
        # a re-sync extend the deadline set at challenge fetch.
        seconds, received_at = server_left
        synced_left = seconds - (time.monotonic() - received_at)
        deadline = Deadline(min(deadline.left(), synced_left), deadline.max_time_s)
    usage_scope = usage_scope or resolve_usage_scope()
    if usage_scope:
        os.environ["ARENA_USAGE_SCOPE"] = usage_scope
    llm = AsyncOpenAI(
        base_url=llm_host,
        api_key=api_key,
        default_headers=build_proxy_headers(agent_id, usage_scope),
        max_retries=0,
    )
    payload = dict(getattr(challenge, "raw_data", {}) or {})
    required = [str(name) for name in payload.get("required_tools") or []]
    # Clues come from tools: drop sentences that order the agent around.
    clues = [scrub_instructions(clue) for clue in clues]
    ctx = ChallengeContext(
        challenge_type=str(challenge.challenge_type or "text"),
        difficulty=str(payload.get("difficulty") or "unknown"),
        challenge_text=str(challenge.description or ""),
        description=str(challenge.description or ""),
        rules=str(challenge.rules or ""),
        clues=clues,
        time_remaining_s=deadline.left(),
        max_time_s=int(challenge.max_time_s or 0),
        available_models=list(models),
        required_tools=required,
    )
    ranked = [model for model in strategy.rank_models(ctx, models) if model in models]
    # Making images cannot produce a text answer; analysis stays available
    # for challenges that include an image.
    toolbox = Toolbox(
        mcp, tool_defs, agent_id=agent_id, extras=extras, budget=deadline.budget,
        hidden={"image_edit", "image_generate"}, link=getattr(mcp, "link", None),
        lister=getattr(mcp, "list_tool_defs", None),
        allowed=set(required) | _named_tools(f"{challenge.description or ''} {challenge.rules or ''}", tool_defs),
    )
    hints = decode_hints([ctx.description, ctx.rules, *clues, json.dumps(extra_fields(payload), default=str)])
    unmet = [name for name in required if name not in called]
    solver = TextSolver(
        llm=llm,
        ranked_models=ranked,
        strategy=strategy,
        toolbox=toolbox,
        deadline=deadline,
        reporter=reporter,
        ctx=ctx,
        payload=payload,
        hints=hints,
        unmet_required=unmet,
    )
    started = time.monotonic()
    result = await solver.solve()
    print(f"   Path: {result.path} · model {result.model} · {result.steps} step(s) · tools {toolbox.called or 'none'}")
    for reason in result.reasons:
        print(f"     - {reason}")

    answer = result.answer
    ctx.time_remaining_s = deadline.left()
    ctx.tokens_used = result.usage["total_tokens"]
    if strategy.should_submit_early(answer, ctx):
        reporter.think("Strategy submitting early.")
    revised = strategy.on_time_warning(deadline.left(), answer, ctx)
    if isinstance(revised, str) and revised.strip():
        answer = revised.strip()
    if not answer:
        # Nothing usable arrived in time. A submission still earns the speed
        # and tool axes; a missing one earns nothing.
        answer = "unknown"

    # A skipped required tool zeroes quality, so call any the model missed, or
    # whose calls all failed, with plain arguments while time allows.
    unmet = [name for name in required if name not in called and name not in toolbox.succeeded]
    for name in unmet:
        if name not in toolbox.defs:
            continue
        for arguments in _required_tool_arguments(toolbox.defs[name], ctx.description):
            if deadline.left() < 2.0:
                break
            outcome = await toolbox.call(name, arguments, timeout_s=5.0)
            if outcome.ok:
                break
    still_unmet = [name for name in required if name not in called and name not in toolbox.succeeded]

    reporter.draft(answer, "final answer")
    reporter.think(f"Answer: {answer}")
    reporter.ensure_one()
    print(f"\n📤 Submitting: {answer}")
    submitted = submit_with_retry(
        http,
        agent_id=agent_id,
        answer=answer,
        client_metrics={
            "model_name": result.model,
            "total_tokens": str(result.usage["total_tokens"]),
            "prompt_tokens": str(result.usage["prompt_tokens"]),
            "completion_tokens": str(result.usage["completion_tokens"]),
            "total_time_ms": int((time.monotonic() - started) * 1000),
        },
    )
    print(f"   Accepted: {submitted.accepted}")
    print(f"   Status: {submitted.status}")
    if submitted.score:
        print(f"   Score: {submitted.score.get('final_score', 0)} (quality {submitted.score.get('quality_score', 0)}, speed {submitted.score.get('speed_score', 0)})")
    note = missing_tools_note(submitted)
    if note:
        print(f"   ⚠️  {note}")
    return {
        "modality": "text",
        "challenge": challenge_record(challenge),
        "answer": answer,
        "model": result.model,
        "path": result.path,
        "reasons": result.reasons,
        "steps": result.steps,
        "notes": result.notes,
        "trace": result.trace,
        "usage": result.usage,
        "tools_called": sorted(called | set(toolbox.called)),
        "tools_succeeded": sorted(called | set(toolbox.succeeded)),
        "required_tools_unmet": still_unmet,
        "tool_log": toolbox.log,
        "hints": hints,
        "result": {"accepted": submitted.accepted, "status": submitted.status, "score": submitted.score},
    }


async def play_image(*, mcp, http, strategy, reporter, agent_id, challenge, tool_defs, tool_names, extras, models, deadline, api_key):
    reporter.think("Image challenge received; planning the image.")
    usage_scope = await asyncio.to_thread(http.fetch_usage_scope) or resolve_usage_scope()
    if usage_scope:
        os.environ["ARENA_USAGE_SCOPE"] = usage_scope
    ctx = image_context(challenge, models)
    ranked = [model for model in strategy.rank_models(ctx, models) if model in models]
    # Reviewers are text/vision models, not the image generators.
    image_only = set(ranked)
    text_ranked = [m for m in strategy.rank_models(ChallengeContext(challenge_type="text"), models) if m not in image_only]
    rank_for_stage = getattr(strategy, "rank_for_stage", None)
    review_order = rank_for_stage("image_review", text_ranked, ctx) if callable(rank_for_stage) else text_ranked
    reviewer = strategy.pick_model("image_review", text_ranked, ctx)
    review_models = [reviewer] + [m for m in review_order if m != reviewer][:1] if reviewer else []
    llm = (
        AsyncOpenAI(
            base_url=get_proxy_host(),
            api_key=api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
            max_retries=0,
        )
        if AsyncOpenAI is not None
        else None
    )
    toolbox = Toolbox(
        mcp, tool_defs, agent_id=agent_id, extras=extras, budget=deadline.budget, link=getattr(mcp, "link", None)
    )
    started = time.monotonic()
    result = await ImageSolver(
        challenge=challenge,
        toolbox=toolbox,
        tool_names=tool_names,
        tool_defs=tool_defs,
        ranked_models=ranked,
        strategy=strategy,
        deadline=deadline,
        reporter=reporter,
        ctx=ctx,
        llm_api_key=api_key,
        arena_api_key=api_key,
        llm=llm,
        review_models=review_models,
    ).solve()
    print(f"   Image: {result.tool or 'none'} with {result.model}; review {result.review or 'skipped'}")
    client_metrics = {
        "model_name": result.model,
        "planner_tool": result.tool,
        "total_time_ms": int((time.monotonic() - started) * 1000),
    }
    reporter.ensure_one()
    print("\n📤 Submitting image...")
    try:
        submitted = await mcp.submit_image(
            agent_id=agent_id,
            image_uri=result.image_uri,
            client_metrics=client_metrics,
            rationale="explorer image flow",
        )
    except Exception as exc:
        print(f"   MCP submit failed ({type(exc).__name__}); submitting over REST")
        rest = submit_with_retry(
            http, agent_id=agent_id, answer=result.image_uri, client_metrics=client_metrics, challenge_type="image"
        )
        submitted = {"accepted": rest.accepted, "score": rest.score}
    for line in submission_summary_lines(submitted):
        print(f"   {line}")
    print(f"   Image: {save_submitted_image(agent_id, result.image_uri, REPO_ROOT)}")
    score = submitted.get("score") if isinstance(submitted.get("score"), dict) else {}
    return {
        "modality": "image",
        "challenge": challenge_record(challenge),
        "model": result.model,
        "tool": result.tool,
        "sequence": result.sequence,
        "review": result.review,
        "notes": result.notes,
        "tools_called": sorted(set(toolbox.called)),
        "result": {
            "accepted": submitted.get("accepted"),
            "score": {key: value for key, value in score.items() if key != "output_image_uri"},
        },
    }


async def main() -> None:
    strategy = MyStrategy()
    agent_id = (os.getenv("AGENT_ID") or str(getattr(strategy, "agent_id", "")).strip() or "explorer-agent").strip()
    agent_name = (os.getenv("AGENT_NAME") or str(getattr(strategy, "agent_name", "")).strip() or "Explorer").strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    if AsyncOpenAI is None:
        raise RuntimeError("Missing dependency: openai. Install with `pip install -r requirements.txt`.")
    print(f"🤖 {agent_name} (explorer) starting · agent id {agent_id}")

    with_startup_retries("Connectivity check", ensure_connected)
    api_base, mcp_url, llm_host, api_key = get_api_base(), get_mcp_url(), get_proxy_host(), get_arena_api_key()
    http = HttpArenaClient(api_base=api_base, api_key=api_key)

    print("📝 Registering...")
    session = with_startup_retries("Registration", lambda: http.register(agent_id, agent_name))
    print(f"   Session: {session.session_id} ({session.status})")
    monitor = monitor_session(http, agent_id).start()
    reporter = Reporter(http, agent_id)
    try:
        # Everything that does not need the challenge happens before the
        # challenge fetch starts its timer.
        models_task = asyncio.create_task(asyncio.to_thread(fetch_available_models, llm_host, api_key))
        link = McpLink(lambda broken: make_mcp_client(mcp_url, broken))
        await link.start(STARTUP_RETRY_S)
        mcp = LinkedMcp(link)
        try:
            tool_defs = await mcp.list_tool_defs()
            tool_names = [str(tool.name) for tool in tool_defs]
            extras: ServerExtras = await discover_extras(getattr(mcp, "_session", None))
            modality = await asyncio.to_thread(McpArenaClient.detect_modality, tool_names, agent_id)
            models = await models_task
            print(f"🔎 {len(tool_names)} tools, {len(models)} models, extras: {extras.listing() or 'none'}")

            modality, challenge = await fetch_challenge(mcp, agent_id, modality, tool_names)
            deadline = Deadline(
                float(getattr(challenge, "time_remaining_s", 0) or 0) or float(challenge.max_time_s or 60),
                float(challenge.max_time_s or 0),
            )
            print_challenge(challenge)
            models = models or await asyncio.to_thread(fetch_available_models, llm_host, api_key)
            require_available_models(models)
            common = dict(
                mcp=mcp, http=http, strategy=strategy, reporter=reporter, agent_id=agent_id,
                challenge=challenge, tool_defs=tool_defs, tool_names=tool_names, extras=extras,
                models=models, deadline=deadline,
            )
            if modality == "image":
                record = await play_image(**common, api_key=api_key)
            else:
                record = await play_text(**common, llm_host=llm_host, api_key=api_key)
        finally:
            await link.close()
    finally:
        await monitor.stop()
    record["agent_id"] = agent_id
    record["thoughts_sent"] = reporter.sent
    record["mcp_reconnects"] = link.reconnects
    print(f"   Run record: {save_run_record(agent_id, record, REPO_ROOT)}")
    print("\n✅ Agent completed!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
    except ModelSelectionError as exc:
        print(f"   {exc}")
        raise SystemExit(1)
